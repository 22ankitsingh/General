"""app.py — Home page. Run: streamlit run app.py"""
import streamlit as st
from utils.session_manager import init_session
from services.s3_connector import test_s3_connection
from services.data_loader import load_all_gold
from components.kpi_cards import render_kpi_row
from components.theme import render_theme_toggle, _apply_theme_css

st.set_page_config(page_title="Ecommerce Analytics", page_icon="🛒", layout="wide")
with open("assets/style.css", encoding="utf-8") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
init_session()

# ── Eagerly apply theme CSS before any content renders ──
_apply_theme_css()

render_theme_toggle()

# ── Sidebar ──────────────────────────────────────────────────────────────────
st.sidebar.markdown("## 🛒 Analytics Copilot")
st.sidebar.caption("Ecommerce Retail Lakehouse")
st.sidebar.markdown("---")
ok, msg = test_s3_connection()
if ok:
    st.sidebar.markdown('<span class="badge badge-green">● S3 Connected</span>', unsafe_allow_html=True)
else:
    st.sidebar.markdown('<span class="badge badge-red">● S3 Disconnected</span>', unsafe_allow_html=True)
    st.sidebar.caption(msg)
st.sidebar.markdown("---")
st.sidebar.caption("Bucket: ecommerce-lakehouse-project-2026")
st.sidebar.caption("Region: ap-south-1")

# ── Page header ──────────────────────────────────────────────────────────────
st.markdown('<div class="page-title">🛒 Ecommerce Analytics Copilot</div>', unsafe_allow_html=True)
st.markdown('<div class="page-subtitle">6 live Gold-layer dashboards · GPT-4o AI assistant · AWS S3 ap-south-1</div>', unsafe_allow_html=True)

if not ok:
    st.error(f"S3 connection failed: {msg}")
    st.code("# Fill .env\nAWS_ACCESS_KEY_ID=\nAWS_SECRET_ACCESS_KEY=\nAWS_SESSION_TOKEN=\nOPENAI_API_KEY=")
    st.stop()

with st.spinner("Loading overview..."):
    try:
        tables = load_all_gold()
        load_ok = True
    except Exception as e:
        st.warning(f"Could not load: {e}")
        load_ok = False

if load_ok:
    ds  = tables["sales_summary"]
    dc  = tables["customer_analytics"]
    dp  = tables["product_performance"]
    di  = tables["inventory_health"]
    dpy = tables["payment_summary"]
    dr  = tables["review_analytics"]

    st.markdown('<div class="section-header">Executive Overview</div>', unsafe_allow_html=True)
    render_kpi_row([
        {"icon": "💰", "label": "Net Revenue",    "value": f"${ds['net_revenue'].sum():,.0f}",   "delta_type": "positive"},
        {"icon": "🛒", "label": "Total Orders",   "value": f"{int(ds['total_orders'].sum()):,}"},
        {"icon": "👥", "label": "Customers",      "value": f"{len(dc):,}"},
        {"icon": "⭐", "label": "Avg LTV",        "value": f"${dc['lifetime_value'].mean():,.0f}"},
        {"icon": "📈", "label": "Total Profit",   "value": f"${dp['profit_estimate'].sum():,.0f}", "delta_type": "positive"},
    ])
    render_kpi_row([
        {"icon": "📦", "label": "Total SKUs",      "value": f"{len(di):,}"},
        {"icon": "⚠️", "label": "Low Stock",       "value": f"{int(di['low_stock_flag'].sum()):,}",
         "delta_type": "negative" if di["low_stock_flag"].sum() > 100 else "neutral"},
        {"icon": "✅", "label": "Payment Success", "value": f"{dpy[dpy['payment_status']=='Success']['transaction_count'].sum()/dpy['transaction_count'].sum()*100:.1f}%",
         "delta_type": "positive"},
        {"icon": "⭐", "label": "Avg Rating",      "value": f"{dr['avg_rating'].mean():.2f}/5.0"},
        {"icon": "📦", "label": "Products",        "value": f"{len(dp):,}"},
    ])
    st.markdown("---")

    st.markdown('<div class="section-header">Dashboard Pages</div>', unsafe_allow_html=True)
    nav = [
        ("📈", "Sales Summary",      "Revenue, orders, AOV"),
        ("👥", "Customer Analytics", "LTV, segments, geography"),
        ("🏭", "Inventory Health",   "Stock levels, alerts"),
        ("💳", "Payment Summary",    "Transactions, fraud"),
        ("📦", "Product Performance","Revenue, profit, ratings"),
        ("⭐", "Review Analytics",   "Ratings, sentiment, NPS"),
        ("🤖", "AI Copilot",         "GPT-4o dynamic dashboards"),
    ]
    cols = st.columns(4)
    for i, (icon, name, desc) in enumerate(nav):
        with cols[i % 4]:
            st.markdown(
                f'<div class="nav-card">'
                f'<span class="nav-card-icon">{icon}</span>'
                f'<div class="nav-card-title">{name}</div>'
                f'<div class="nav-card-desc">{desc}</div>'
                f'</div>',
                unsafe_allow_html=True,
            )
            st.markdown("")
    st.markdown("---")
    st.caption("Data cached 1 h · AWS S3 ap-south-1 · Gold Parquet")
