"""
pages/5_📦_Product_Performance.py
"""
import streamlit as st
from utils.session_manager import init_session, increment_refresh
from services.data_loader import load_gold
from dashboards.product_performance import render
from components.theme import render_theme_toggle, _apply_theme_css

st.set_page_config(page_title="Product Performance", page_icon="📦", layout="wide")

with open("assets/style.css", encoding="utf-8") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

init_session()
_apply_theme_css()
render_theme_toggle()

col1, col2 = st.sidebar.columns([3,1])
with col2:
    if st.button("🔄", help="Refresh data"):
        increment_refresh()

with st.spinner("Loading Product Performance data..."):
    df = load_gold("product_performance")

render(df)
