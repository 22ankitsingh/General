"""pages/7_🤖_AI_Copilot.py"""
import streamlit as st
import json
from utils.session_manager import init_session, add_message, get_api_history, clear_chat
from services.data_loader import load_all_gold
from ai.dashboard_engine import run_analysis, render_dashboard_spec
from utils.export_service import download_pdf_button
from components.theme import render_theme_toggle, _apply_theme_css

st.set_page_config(page_title="AI Copilot", page_icon="🤖", layout="wide")
with open("assets/style.css", encoding="utf-8") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
init_session()
_apply_theme_css()
render_theme_toggle()

st.sidebar.markdown("## 🤖 AI Analytics Copilot")
st.sidebar.markdown('<span class="badge badge-blue">GPT-4o</span>', unsafe_allow_html=True)
st.sidebar.markdown("---")
QUICK_QS=["Revenue growth drivers","Convert Bronze to Gold customers",
          "Highest profit margin products","Inventory stockout risk",
          "Payment fraud analysis","India vs US comparison",
          "Products with declining reviews","Top actions to grow revenue",
          "Payment failure trends","Customer retention dashboard"]
st.sidebar.markdown('<div class="section-header">Quick Questions</div>', unsafe_allow_html=True)
for q in QUICK_QS:
    if st.sidebar.button(q, key=f"qq_{q[:12]}", use_container_width=True):
        st.session_state["_pending_question"]=q
st.sidebar.markdown("---")
if st.sidebar.button("🗑️ Clear Chat", use_container_width=True):
    clear_chat(); st.rerun()

st.markdown('<div class="page-title">🤖 AI Analytics Copilot</div>', unsafe_allow_html=True)
st.markdown('<div class="page-subtitle">Ask any business question — GPT-4o analyses your live data and builds dashboards on demand</div>', unsafe_allow_html=True)

@st.cache_data(show_spinner=False, ttl=3600)
def get_all_data(): return load_all_gold()
with st.spinner("Loading data..."):
    try: all_data=get_all_data()
    except Exception as e: st.error(f"Failed: {e}"); st.stop()

pending=st.session_state.pop("_pending_question",None)
question=st.chat_input("Ask a business question...") or pending

for msg in st.session_state.chat_history:
    if msg["role"]=="user":
        with st.chat_message("user"): st.markdown(msg["content"])
    else:
        with st.chat_message("assistant", avatar="🤖"):
            render_dashboard_spec(msg["spec"],all_data) if msg.get("spec") else st.markdown(msg["content"])

if question:
    with st.chat_message("user"): st.markdown(question)
    add_message("user", question)
    with st.chat_message("assistant", avatar="🤖"):
        with st.spinner("Analysing..."):
            try:
                spec=run_analysis(question, all_data, conversation_history=get_api_history()[:-1])
                st.session_state.last_spec=spec
                render_dashboard_spec(spec, all_data)
                add_message("assistant", json.dumps(spec), spec=spec)
                kpis=spec.get("kpis",[]); ins=spec.get("insights",[]); recs=spec.get("recommendations",[])
                if kpis or ins:
                    st.markdown("---")
                    download_pdf_button(title=spec.get("intent","Report").replace("_"," ").title(),
                                       kpis=kpis, insights=ins, recommendations=recs, filename="report.pdf")
            except Exception as e:
                err=f"Error: {e}. Check your OPENAI_API_KEY in .env."
                st.error(err); add_message("assistant", err)
