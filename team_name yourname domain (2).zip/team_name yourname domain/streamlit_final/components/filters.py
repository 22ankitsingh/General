"""
components/filters.py — Sidebar filter widgets per dashboard.
"""
import streamlit as st
import pandas as pd
from datetime import date


def date_filter(df: pd.DataFrame, date_col: str = "order_date") -> tuple[date, date]:
    """Date range filter."""
    if date_col not in df.columns:
        return None, None
    col = pd.to_datetime(df[date_col], errors="coerce").dropna()
    if col.empty:
        return None, None
    mn, mx = col.min().date(), col.max().date()
    st.sidebar.markdown("**Date Range**")
    start = st.sidebar.date_input("From", value=mn, min_value=mn, max_value=mx, key=f"date_start_{date_col}")
    end   = st.sidebar.date_input("To",   value=mx, min_value=mn, max_value=mx, key=f"date_end_{date_col}")
    return start, end


def multiselect_filter(df: pd.DataFrame, col: str, label: str, default_all: bool = True):
    """Multi-select sidebar filter for a categorical column."""
    if col not in df.columns:
        return None
    opts = sorted(df[col].dropna().unique().tolist())
    if not opts:
        return None
    default = opts if default_all else []
    return st.sidebar.multiselect(label, options=opts, default=default, key=f"ms_{col}")


def apply_date_filter(df: pd.DataFrame, date_col: str, start, end) -> pd.DataFrame:
    if start is None or end is None or date_col not in df.columns:
        return df
    col = pd.to_datetime(df[date_col], errors="coerce")
    return df[(col.dt.date >= start) & (col.dt.date <= end)]


def apply_multiselect_filter(df: pd.DataFrame, col: str, values) -> pd.DataFrame:
    if not values or col not in df.columns:
        return df
    return df[df[col].isin(values)]


# ── Per-dashboard filter bundles ─────────────────────────────────────────────

def sales_filters(df: pd.DataFrame) -> dict:
    st.sidebar.markdown("## 🔍 Filters")
    start, end = date_filter(df, "order_date")
    years = multiselect_filter(df, "order_year", "Year")
    months = multiselect_filter(df, "order_month", "Month")
    return {"start": start, "end": end, "order_year": years, "order_month": months}


def customer_filters(df: pd.DataFrame) -> dict:
    st.sidebar.markdown("## 🔍 Filters")
    countries  = multiselect_filter(df, "country",          "Country")
    segments   = multiselect_filter(df, "customer_segment", "Segment")
    statuses   = multiselect_filter(df, "customer_status",  "Status")
    pay_methods= multiselect_filter(df, "preferred_payment_method", "Pref. Payment")
    return {"country": countries, "customer_segment": segments,
            "customer_status": statuses, "preferred_payment_method": pay_methods}


def product_filters(df: pd.DataFrame) -> dict:
    st.sidebar.markdown("## 🔍 Filters")
    categories = multiselect_filter(df, "category",    "Category")
    brands     = multiselect_filter(df, "brand",       "Brand")
    return {"category": categories, "brand": brands}


def inventory_filters(df: pd.DataFrame) -> dict:
    st.sidebar.markdown("## 🔍 Filters")
    countries  = multiselect_filter(df, "warehouse_country", "Warehouse Country")
    statuses   = multiselect_filter(df, "inventory_status",  "Inventory Status")
    return {"warehouse_country": countries, "inventory_status": statuses}


def payment_filters(df: pd.DataFrame) -> dict:
    st.sidebar.markdown("## 🔍 Filters")
    start, end = date_filter(df, "payment_date")
    methods = multiselect_filter(df, "payment_method", "Payment Method")
    statuses= multiselect_filter(df, "payment_status", "Payment Status")
    return {"start": start, "end": end, "payment_method": methods, "payment_status": statuses}


def review_filters(df: pd.DataFrame) -> dict:
    st.sidebar.markdown("## 🔍 Filters")
    start, end = date_filter(df, "review_date")
    cats       = multiselect_filter(df, "category",         "Category")
    sentiments = multiselect_filter(df, "sentiment",        "Sentiment")
    nps        = multiselect_filter(df, "nps_category",     "NPS Category")
    segments   = multiselect_filter(df, "customer_segment", "Customer Segment")
    countries  = multiselect_filter(df, "country",          "Country")
    return {"start": start, "end": end, "category": cats, "sentiment": sentiments,
            "nps_category": nps, "customer_segment": segments, "country": countries}


def apply_filters(df: pd.DataFrame, filters: dict, date_col: str | None = None) -> pd.DataFrame:
    """Generic filter application. Handles date range + any multiselect filters."""
    result = df.copy()
    if date_col and filters.get("start") and filters.get("end"):
        result = apply_date_filter(result, date_col, filters["start"], filters["end"])
    skip = {"start", "end"}
    for col, vals in filters.items():
        if col in skip:
            continue
        result = apply_multiselect_filter(result, col, vals)
    return result
