"""
components/theme.py — Light/Dark theme toggle for Streamlit sidebar.

Usage (add to every page, after init_session()):
    from components.theme import render_theme_toggle
"""
import streamlit as st
import plotly.io as pio

# ── Dark-theme CSS — full design-token override ──────────────────────────────
# Re-declares ALL tokens so dark mode is fully self-contained; style.css :root
# values are the initial dark defaults, but this block guarantees dark mode even
# if Streamlit's client-side framework overrides :root.
_DARK_CSS = """
<style data-theme="dark">
:root {
  --bg-base:        #070b14;
  --bg-surface:     #0d1117;
  --bg-card:        #111827;
  --bg-card-hover:  #141d2e;
  --bg-elevated:    #1a2332;
  --border:         #1e293b;
  --border-subtle:  #162032;
  --border-focus:   #3b82f6;

  --text-primary:   #f1f5f9;
  --text-secondary: #94a3b8;
  --text-muted:     #475569;
  --text-disabled:  #334155;

  --accent-blue:    #3b82f6;
  --accent-cyan:    #06b6d4;
  --accent-emerald: #10b981;
  --accent-amber:   #f59e0b;
  --accent-red:     #ef4444;
  --accent-violet:  #8b5cf6;
  --accent-pink:    #ec4899;
  --accent-orange:  #f97316;

  --gradient-blue:  linear-gradient(135deg, #3b82f6 0%, #06b6d4 100%);
  --gradient-green: linear-gradient(135deg, #10b981 0%, #06b6d4 100%);
  --gradient-warm:  linear-gradient(135deg, #f59e0b 0%, #f97316 100%);
  --gradient-violet:linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%);

  --shadow-sm:      0 1px 3px rgba(0,0,0,0.4);
  --shadow-md:      0 4px 16px rgba(0,0,0,0.4);
  --shadow-lg:      0 8px 32px rgba(0,0,0,0.5);
  --shadow-glow:    0 0 24px rgba(59,130,246,0.18);

  --accent-red-bg:      rgba(239,68,68,0.06);
  --accent-red-border:  rgba(239,68,68,0.25);
  --accent-amber-bg:    rgba(245,158,11,0.06);
  --accent-amber-border:rgba(245,158,11,0.25);
  --accent-blue-bg:     rgba(59,130,246,0.06);
  --accent-blue-border: rgba(59,130,246,0.25);
  --accent-green-bg:    rgba(16,185,129,0.06);
  --accent-green-border:rgba(16,185,129,0.25);
}

/* Force Streamlit's own themed elements to dark */
.stApp {
  background: var(--bg-base) !important;
  background-image:
    radial-gradient(ellipse 80% 50% at 50% -20%, rgba(59,130,246,0.06), transparent),
    radial-gradient(ellipse 60% 40% at 80% 80%, rgba(6,182,212,0.04), transparent) !important;
}
section[data-testid="stSidebar"] {
  background: var(--bg-surface) !important;
  border-right: 1px solid var(--border) !important;
}
</style>
"""

# ── Light-theme CSS — Premium enterprise analytics light theme ───────────────
# Inspired by Tableau, Power BI, Databricks, Snowflake, Grafana Light,
# AWS Console, and Azure Portal. Uses a warm neutral palette with crisp
# blue accents, subtle shadows, and excellent contrast ratios.
_LIGHT_CSS = """
<style data-theme="light">
:root {
  /* ── Core surfaces ── */
  --bg-base:        #f4f6f9;
  --bg-surface:     #ffffff;
  --bg-card:        #ffffff;
  --bg-card-hover:  #f8fafd;
  --bg-elevated:    #f0f3f7;
  --border:         #dfe3ea;
  --border-subtle:  #e8ecf1;
  --border-focus:   #2563eb;

  /* ── Typography ── */
  --text-primary:   #111827;
  --text-secondary: #374151;
  --text-muted:     #6b7280;
  --text-disabled:  #9ca3af;

  /* ── Accent palette (stays vivid) ── */
  --accent-blue:    #2563eb;
  --accent-cyan:    #0891b2;
  --accent-emerald: #059669;
  --accent-amber:   #d97706;
  --accent-red:     #dc2626;
  --accent-violet:  #7c3aed;
  --accent-pink:    #db2777;
  --accent-orange:  #ea580c;

  /* ── Gradients ── */
  --gradient-blue:  linear-gradient(135deg, #2563eb 0%, #0891b2 100%);
  --gradient-green: linear-gradient(135deg, #059669 0%, #0891b2 100%);
  --gradient-warm:  linear-gradient(135deg, #d97706 0%, #ea580c 100%);
  --gradient-violet:linear-gradient(135deg, #7c3aed 0%, #db2777 100%);

  /* ── Shadows (light-appropriate) ── */
  --shadow-sm:      0 1px 2px rgba(0,0,0,0.04), 0 1px 3px rgba(0,0,0,0.06);
  --shadow-md:      0 2px 4px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.06);
  --shadow-lg:      0 4px 8px rgba(0,0,0,0.04), 0 8px 24px rgba(0,0,0,0.08);
  --shadow-glow:    0 0 20px rgba(37,99,235,0.10);

  /* ── Accent backgrounds (for badges / alerts) ── */
  --accent-red-bg:      #fef2f2;
  --accent-red-border:  #fecaca;
  --accent-amber-bg:    #fffbeb;
  --accent-amber-border:#fde68a;
  --accent-blue-bg:     #eff6ff;
  --accent-blue-border: #bfdbfe;
  --accent-green-bg:    #ecfdf5;
  --accent-green-border:#a7f3d0;
}

/* ── App shell ── */
.stApp {
  background: var(--bg-base) !important;
  background-image: none !important;
}

/* ── Sidebar ── */
section[data-testid="stSidebar"] {
  background: var(--bg-surface) !important;
  border-right: 1px solid var(--border) !important;
  box-shadow: 2px 0 8px rgba(0,0,0,0.03) !important;
}

/* Sidebar nav links hover */
section[data-testid="stSidebar"] [data-testid="stSidebarNav"] a:hover {
  background: var(--accent-blue-bg) !important;
}

/* Sidebar buttons */
section[data-testid="stSidebar"] .stButton > button {
  background: transparent !important;
  border: 1px solid var(--border) !important;
  color: var(--text-muted) !important;
}
section[data-testid="stSidebar"] .stButton > button:hover {
  border-color: var(--accent-blue) !important;
  color: var(--accent-blue) !important;
  background: var(--accent-blue-bg) !important;
}

/* Sidebar collapse button */
[data-testid="stSidebarCollapseButton"] button {
  border: 1px solid var(--border) !important;
  background: var(--bg-surface) !important;
}
[data-testid="stSidebarCollapseButton"] button:hover {
  background: var(--accent-blue-bg) !important;
  border-color: var(--accent-blue) !important;
}
[data-testid="stSidebarCollapseButton"] svg {
  color: var(--text-muted) !important;
  fill: var(--text-muted) !important;
}

/* ── KPI cards ── */
.kpi-card {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  box-shadow: var(--shadow-sm) !important;
}
.kpi-card:hover {
  background: var(--bg-card-hover) !important;
  box-shadow: var(--shadow-md), 0 0 0 1px rgba(37,99,235,0.12) !important;
  border-color: rgba(37,99,235,0.35) !important;
}
.kpi-card::after {
  background: radial-gradient(circle, rgba(37,99,235,0.04) 0%, transparent 70%) !important;
}

/* ── Nav cards (home page) ── */
.nav-card {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  box-shadow: var(--shadow-sm) !important;
}
.nav-card:hover {
  background: var(--bg-card-hover) !important;
  border-color: rgba(37,99,235,0.4) !important;
  box-shadow: var(--shadow-md) !important;
}

/* ── Buttons ── */
.stButton > button {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  color: var(--text-secondary) !important;
  box-shadow: var(--shadow-sm) !important;
}
.stButton > button:hover {
  border-color: var(--accent-blue) !important;
  color: var(--accent-blue) !important;
  background: var(--accent-blue-bg) !important;
  box-shadow: 0 0 0 1px var(--accent-blue-border) !important;
}
.stDownloadButton > button {
  background: var(--gradient-blue) !important;
  color: white !important;
  border: none !important;
  box-shadow: 0 2px 8px rgba(37,99,235,0.25) !important;
}
.stDownloadButton > button:hover {
  box-shadow: 0 4px 16px rgba(37,99,235,0.35) !important;
}

/* ── Select / multiselect ── */
.stSelectbox > div > div,
.stMultiSelect > div > div {
  background: var(--bg-card) !important;
  border-color: var(--border) !important;
  color: var(--text-primary) !important;
}
.stSelectbox > div > div:focus-within,
.stMultiSelect > div > div:focus-within {
  border-color: var(--accent-blue) !important;
  box-shadow: 0 0 0 2px var(--accent-blue-bg) !important;
}
.stDateInput > div > div {
  background: var(--bg-card) !important;
  border-color: var(--border) !important;
}

/* ── Multiselect pills ── */
[data-baseweb="tag"] {
  background: var(--accent-blue-bg) !important;
  border: 1px solid var(--accent-blue-border) !important;
}
[data-baseweb="tag"] span { color: var(--accent-blue) !important; }

/* ── Chat UI ── */
[data-testid="stChatMessage"] {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  box-shadow: var(--shadow-sm) !important;
}
.stChatInput > div {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
}
.stChatInput > div:focus-within {
  border-color: var(--accent-blue) !important;
  box-shadow: 0 0 0 2px rgba(37,99,235,0.08) !important;
}
.stChatInput textarea { color: var(--text-primary) !important; }

/* ── Chart containers ── */
.chart-section {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  box-shadow: var(--shadow-sm) !important;
}
.chart-section:hover {
  box-shadow: var(--shadow-md) !important;
}

/* ── Insight cards ── */
.insight-card {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  box-shadow: var(--shadow-sm) !important;
}
.insight-card:hover { border-color: rgba(37,99,235,0.3) !important; }

/* ── Exec summary ── */
.exec-summary {
  background: linear-gradient(135deg, var(--accent-blue-bg), #f0f9ff) !important;
  border: 1px solid var(--accent-blue-border) !important;
  border-left: 3px solid var(--accent-blue) !important;
  color: var(--text-secondary) !important;
}
.exec-summary b { color: var(--accent-blue) !important; }

/* ── Alert banners ── */
.alert-danger {
  background: var(--accent-red-bg) !important;
  border: 1px solid var(--accent-red-border) !important;
  border-left: 3px solid var(--accent-red) !important;
  color: var(--accent-red) !important;
}
.alert-warning {
  background: var(--accent-amber-bg) !important;
  border: 1px solid var(--accent-amber-border) !important;
  border-left: 3px solid var(--accent-amber) !important;
  color: var(--accent-amber) !important;
}
.alert-info {
  background: var(--accent-blue-bg) !important;
  border: 1px solid var(--accent-blue-border) !important;
  border-left: 3px solid var(--accent-blue) !important;
  color: var(--accent-blue) !important;
}

/* ── Recommendation cards ── */
.rec-high   { background: var(--accent-red-bg) !important; border-color: var(--accent-red-border) !important; }
.rec-medium { background: var(--accent-amber-bg) !important; border-color: var(--accent-amber-border) !important; }
.rec-low    { background: var(--accent-green-bg) !important; border-color: var(--accent-green-border) !important; }

/* ── Badges ── */
.badge-green  { color: var(--accent-emerald) !important; }
.badge-red    { color: var(--accent-red) !important; }

/* ── Table (st.dataframe) ── */
[data-testid="stDataFrame"] {
  border: 1px solid var(--border) !important;
  box-shadow: var(--shadow-sm) !important;
}

/* ── Expander ── */
.streamlit-expanderHeader {
  background: var(--bg-card) !important;
  border: 1px solid var(--border) !important;
  color: var(--text-secondary) !important;
}

/* ── Scrollbar (light) ── */
::-webkit-scrollbar-track { background: var(--bg-base) !important; }
::-webkit-scrollbar-thumb { background: #c4c9d4 !important; }
::-webkit-scrollbar-thumb:hover { background: #a8adb8 !important; }

/* ── Dividers ── */
hr { border-top-color: var(--border) !important; }

/* ── Streamlit notification / alert ── */
.stAlert { border-radius: 10px !important; }
</style>
"""


def _apply_theme_css() -> None:
    """Inject the correct CSS block and set Plotly's global template.

    Called EAGERLY — before any chart or widget is rendered — to ensure
    there is never a flash of the wrong theme.
    """
    is_dark = st.session_state.get("dark_mode", True)

    # 1. Set Plotly global template
    pio.templates.default = "plotly_dark" if is_dark else "plotly"

    # 2. Inject CSS overrides (idempotent — Streamlit de-duplicates <style> blocks)
    st.markdown(_DARK_CSS if is_dark else _LIGHT_CSS, unsafe_allow_html=True)


def render_theme_toggle() -> None:
    """Render a ☀/🌙 toggle in the sidebar and inject the appropriate CSS.
    Call this on every page immediately after init_session().
    """
    # ── Apply CSS eagerly (before toggle renders) ──
    _apply_theme_css()

    is_dark = st.session_state.get("dark_mode", True)
    toggle_label = "☀️ Light mode" if is_dark else "🌙 Dark mode"

    st.sidebar.markdown(
        '<div style="font-size:0.72rem;color:var(--text-muted);'
        'text-transform:uppercase;letter-spacing:0.08em;font-weight:600;'
        'margin-bottom:4px;">Theme</div>',
        unsafe_allow_html=True,
    )
    clicked = st.sidebar.button(
        toggle_label,
        key="theme_toggle_btn",
        help="Switch between dark and light mode",
        use_container_width=True,
    )

    if clicked:
        st.session_state["dark_mode"] = not is_dark
        st.rerun()

    st.sidebar.markdown("---")
