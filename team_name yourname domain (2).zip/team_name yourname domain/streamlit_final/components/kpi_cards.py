"""
components/kpi_cards.py — Enterprise-grade KPI card components v2.0.
"""
import streamlit as st


def kpi_card(
    icon: str,
    label: str,
    value: str,
    delta: str = "",
    delta_type: str = "neutral",
    accent: str = "blue",
) -> str:
    delta_class = delta_type if delta_type in ("positive", "negative") else "neutral"
    delta_arrow = "▲" if delta_type == "positive" else ("▼" if delta_type == "negative" else "")
    delta_html = (
        f'<div class="kpi-delta {delta_class}">{delta_arrow} {delta}</div>'
        if delta else ""
    )
    card_class = f"kpi-card {'negative-card' if delta_type == 'negative' else 'positive-card' if delta_type == 'positive' else ''}"
    return f"""
<div class="{card_class}">
  <span class="kpi-icon">{icon}</span>
  <div class="kpi-label">{label}</div>
  <div class="kpi-value">{value}</div>
  {delta_html}
</div>"""


def render_kpi_row(kpis: list[dict]) -> None:
    cards_html = "".join(
        kpi_card(
            k.get("icon", "📊"),
            k.get("label", ""),
            k.get("value", ""),
            k.get("delta", ""),
            k.get("delta_type", "neutral"),
            k.get("accent", "blue"),
        )
        for k in kpis
    )
    st.markdown(f'<div class="kpi-row">{cards_html}</div>', unsafe_allow_html=True)


def render_alert_banner(message: str, alert_type: str = "info") -> None:
    css_class = f"alert-{alert_type}" if alert_type in ("danger", "warning", "info") else "alert-info"
    icons = {"danger": "🔴", "warning": "🟡", "info": "🔵"}
    icon = icons.get(alert_type, "ℹ️")
    st.markdown(f'<div class="{css_class}">{icon} {message}</div>', unsafe_allow_html=True)
