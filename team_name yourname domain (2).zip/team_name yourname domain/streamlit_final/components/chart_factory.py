"""components/chart_factory.py — Enterprise Plotly chart factory v2.1 (theme-aware)."""
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from config import CHART_COLORS

# ── Plotly display config — full interactivity ──────────────────────────────
PLOTLY_CONFIG = dict(
    displayModeBar=True,
    responsive=True,
    scrollZoom=False,
    doubleClick="reset",
    modeBarButtonsToRemove=["select2d", "lasso2d", "autoScale2d"],
    modeBarButtonsToAdd=["drawline", "drawopenpath", "eraseshape"],
    displaylogo=False,
    toImageButtonOptions=dict(format="png", filename="chart", height=600, width=1200, scale=2),
)

# ── Per-theme palette helpers (called at render time, not import time) ────────

def _is_dark() -> bool:
    """True when the app is in dark mode (default)."""
    return st.session_state.get("dark_mode", True)


def _theme() -> dict:
    """Return a dict of theme-specific color tokens for charts."""
    if _is_dark():
        return dict(
            template      = "plotly_dark",
            paper_bg      = "#111827",
            plot_bg       = "#111827",
            grid          = "#1e293b",
            axis_line     = "#1e293b",
            tick_color    = "#64748b",
            font_color    = "#94a3b8",
            title_color   = "#e2e8f0",
            legend_color  = "#94a3b8",
            hover_bg      = "#1a2332",
            hover_border  = "#1e293b",
            hover_font    = "#e2e8f0",
            table_header  = "#1a2332",
            table_header_font = "#e2e8f0",
            table_row_even= "#111827",
            table_row_odd = "#0f1623",
            table_line    = "#1e293b",
            table_font    = "#94a3b8",
            pie_line      = "#0d1117",
            treemap_line  = "#0d1117",
        )
    else:
        return dict(
            template      = "plotly",
            paper_bg      = "#ffffff",
            plot_bg       = "#f8fafc",
            grid          = "#e2e8f0",
            axis_line     = "#e2e8f0",
            tick_color    = "#64748b",
            font_color    = "#475569",
            title_color   = "#0f172a",
            legend_color  = "#475569",
            hover_bg      = "#ffffff",
            hover_border  = "#e2e8f0",
            hover_font    = "#0f172a",
            table_header  = "#f1f5f9",
            table_header_font = "#0f172a",
            table_row_even= "#ffffff",
            table_row_odd = "#f8fafc",
            table_line    = "#e2e8f0",
            table_font    = "#334155",
            pie_line      = "#ffffff",
            treemap_line  = "#ffffff",
        )


def _base_layout(height: int = 400) -> dict:
    """Build a fresh base layout dict from the current theme (called at render time)."""
    t = _theme()
    return dict(
        template     = t["template"],
        paper_bgcolor= t["paper_bg"],
        plot_bgcolor = t["plot_bg"],
        font         = dict(color=t["font_color"], family="Inter, -apple-system, sans-serif", size=12),
        margin       = dict(l=24, r=24, t=52, b=24),
        height       = height,
        colorway     = CHART_COLORS,
        legend       = dict(
            bgcolor     = "rgba(0,0,0,0)",
            font        = dict(size=11, color=t["legend_color"]),
            orientation = "h",
            y           = -0.18,
            x           = 0,
            bordercolor = "rgba(255,255,255,0)",
            itemsizing  = "constant",
        ),
        xaxis = dict(
            gridcolor  = t["grid"],
            linecolor  = t["axis_line"],
            tickfont   = dict(size=11, color=t["tick_color"]),
            title_font = dict(size=12, color=t["tick_color"]),
            showgrid   = True,
            zeroline   = False,
        ),
        yaxis = dict(
            gridcolor  = t["grid"],
            linecolor  = t["axis_line"],
            tickfont   = dict(size=11, color=t["tick_color"]),
            title_font = dict(size=12, color=t["tick_color"]),
            showgrid   = True,
            zeroline   = False,
        ),
        hoverlabel = dict(
            bgcolor    = t["hover_bg"],
            bordercolor= t["hover_border"],
            font       = dict(size=12, color=t["hover_font"], family="Inter, sans-serif"),
        ),
    )


def _title_dict(title: str) -> dict:
    return dict(
        text     = f"<b>{title}</b>",
        font     = dict(color=_theme()["title_color"], size=14, family="Inter, sans-serif"),
        x        = 0.01,
        xanchor  = "left",
        pad      = dict(l=4, t=4),
    )


def apply_layout(fig, title: str = "", height: int = 400):
    d = _base_layout(height)
    if title:
        d["title"] = _title_dict(title)
    fig.update_layout(**d)
    return fig


# Alias for internal use
_lay = apply_layout


def display_chart(fig, key: str = None):
    """Render a Plotly chart with full interactivity enabled."""
    st.plotly_chart(fig, use_container_width=True, config=PLOTLY_CONFIG, key=key)


# ── Chart types ───────────────────────────────────────────────────────────────

def bar_chart(df, x, y, title="", orientation="v", color=None, color_map=None, height=400):
    kw = dict(color_discrete_map=color_map) if color_map else {}
    fig = px.bar(
        df, x=x, y=y, orientation=orientation, color=color,
        color_discrete_sequence=CHART_COLORS, **kw,
    )
    ht = (
        "<b>%{x}</b><br>Value: %{y:,.2f}<extra></extra>"
        if orientation == "v"
        else "<b>%{y}</b><br>Value: %{x:,.2f}<extra></extra>"
    )
    fig.update_traces(marker_line_width=0, hovertemplate=ht)
    return apply_layout(fig, title, height)


def line_chart(df, x, y, title="", color=None, height=400):
    fig = px.line(df, x=x, y=y, color=color, color_discrete_sequence=CHART_COLORS, markers=True)
    fig.update_traces(
        line_width=2.5,
        marker_size=6,
        marker_line_width=0,
        hovertemplate="<b>%{x}</b><br>%{y:,.2f}<extra></extra>",
    )
    return apply_layout(fig, title, height)


def pie_chart(df, names, values, title="", hole=0.52, color_map=None, height=400):
    kw = dict(color_discrete_map=color_map) if color_map else {}
    fig = px.pie(
        df, names=names, values=values, hole=hole,
        color_discrete_sequence=CHART_COLORS, color=names, **kw,
    )
    t = _theme()
    fig.update_traces(
        textposition="outside",
        textinfo="percent+label",
        pull=[0.02] * len(df),
        marker=dict(line=dict(color=t["pie_line"], width=2)),
        hovertemplate="<b>%{label}</b><br>Count: %{value:,}<br>Share: %{percent}<extra></extra>",
    )
    # pie has no axes
    d = {k: v for k, v in _base_layout(height).items() if k not in ("xaxis", "yaxis")}
    if title:
        d["title"] = _title_dict(title)
    fig.update_layout(**d)
    return fig


def scatter_chart(df, x, y, title="", color=None, size=None, hover_data=None, color_map=None, height=400):
    kw = dict(color_discrete_map=color_map) if color_map else {}
    fig = px.scatter(
        df, x=x, y=y, color=color, size=size, hover_data=hover_data,
        color_discrete_sequence=CHART_COLORS, **kw,
    )
    fig.update_traces(
        marker=dict(opacity=0.8, line=dict(width=0), size=7),
        hovertemplate=(
            "<b>%{customdata[0]}</b><br>X: %{x:,.2f}<br>Y: %{y:,.2f}<extra></extra>"
            if hover_data
            else "<b>%{x:,.2f}, %{y:,.2f}</b><extra></extra>"
        ),
    )
    return apply_layout(fig, title, height)


def heatmap_chart(df, x, y, values, title="", height=400):
    pivot = df.pivot_table(index=y, columns=x, values=values, aggfunc="mean")
    t = _theme()
    # Light scale: white → blue-tint; Dark scale: near-black → deep blue
    colorscale = (
        [[0, "#f8fafc"], [0.5, "#bfdbfe"], [1, "#3b82f6"]]
        if not _is_dark()
        else [[0, "#0d1117"], [0.5, "#1e3a5f"], [1, "#3b82f6"]]
    )
    fig = go.Figure(go.Heatmap(
        z=pivot.values,
        x=[str(c) for c in pivot.columns],
        y=[str(r) for r in pivot.index],
        colorscale=colorscale,
        showscale=True,
        hovertemplate="<b>%{y} × %{x}</b><br>Value: %{z:,.1f}<extra></extra>",
        colorbar=dict(
            thickness=12, len=0.8, x=1.02,
            tickfont=dict(color=t["tick_color"], size=10),
            bgcolor="rgba(0,0,0,0)",
        ),
    ))
    return apply_layout(fig, title, height)


def treemap_chart(df, path, values, title="", color=None, height=420):
    t = _theme()
    color_scale = (
        [[0, "#dbeafe"], [0.5, "#3b82f6"], [1, "#1d4ed8"]]
        if not _is_dark()
        else [[0, "#1e3a5f"], [0.5, "#2563eb"], [1, "#06b6d4"]]
    )
    fig = px.treemap(
        df, path=path, values=values, color=color,
        color_continuous_scale=color_scale,
    )
    fig.update_traces(
        hovertemplate="<b>%{label}</b><br>Value: %{value:,.0f}<br>Parent: %{parent}<extra></extra>",
        marker=dict(line=dict(color=t["treemap_line"], width=2)),
    )
    d = {k: v for k, v in _base_layout(height).items() if k not in ("xaxis", "yaxis")}
    if title:
        d["title"] = _title_dict(title)
    fig.update_layout(**d)
    return fig


def box_chart(df, x, y, title="", color=None, color_map=None, height=400):
    kw = dict(color_discrete_map=color_map) if color_map else {}
    fig = px.box(
        df, x=x, y=y, color=color, color_discrete_sequence=CHART_COLORS,
        notched=False, **kw,
    )
    fig.update_traces(
        marker=dict(size=4, opacity=0.6),
        line=dict(width=1.5),
        hovertemplate="<b>%{x}</b><br>Median: %{median:,.1f}<extra></extra>",
    )
    return apply_layout(fig, title, height)


def grouped_bar(df, x, y, color, title="", barmode="group", color_map=None, height=400):
    kw = dict(color_discrete_map=color_map) if color_map else {}
    fig = px.bar(
        df, x=x, y=y, color=color, barmode=barmode,
        color_discrete_sequence=CHART_COLORS, **kw,
    )
    fig.update_traces(
        marker_line_width=0,
        hovertemplate="<b>%{x}</b><br>%{y:,.2f}<extra></extra>",
    )
    return apply_layout(fig, title, height)


def stacked_area(df, x, y, color, title="", height=400):
    fig = px.area(df, x=x, y=y, color=color, color_discrete_sequence=CHART_COLORS)
    fig.update_traces(
        line_width=1.5,
        hovertemplate="<b>%{x}</b><br>%{y:,.2f}<extra></extra>",
    )
    return apply_layout(fig, title, height)


def kpi_table(df, title="", height=400):
    t = _theme()
    n = len(df)
    row_colors = [t["table_row_even"] if i % 2 == 0 else t["table_row_odd"] for i in range(n)]
    fig = go.Figure(go.Table(
        header=dict(
            values=[f"<b>{c}</b>" for c in df.columns],
            fill_color=t["table_header"],
            font=dict(color=t["table_header_font"], size=12, family="Inter, sans-serif"),
            align="left",
            line_color=t["table_line"],
            height=38,
        ),
        cells=dict(
            values=[df[c] for c in df.columns],
            fill_color=[[row_colors[i] for i in range(n)] for _ in df.columns],
            font=dict(color=t["table_font"], size=11, family="Inter, sans-serif"),
            align="left",
            line_color=t["table_line"],
            height=34,
        ),
    ))
    d = {k: v for k, v in _base_layout(height).items() if k not in ("xaxis", "yaxis")}
    d["margin"] = dict(l=0, r=0, t=44 if title else 8, b=0)
    if title:
        d["title"] = _title_dict(title)
    fig.update_layout(**d)
    return fig


# ── AI Copilot chart renderer ─────────────────────────────────────────────────

def render_chart_spec(spec, data):
    if not spec:
        return None
    chart_type = spec.get("type", "bar")
    dataset    = spec.get("dataset", "")
    title      = spec.get("title", "")
    x_col      = spec.get("x", "")
    y_col      = spec.get("y", "")
    color_col  = spec.get("color")
    groupby    = spec.get("groupby", [])
    agg        = spec.get("aggregation", "sum")
    color_map  = spec.get("color_map") or None

    df = data.get(dataset)
    if df is None or df.empty:
        return None

    if groupby and y_col:
        try:
            fn = getattr(df.groupby(groupby)[y_col], agg, None)
            if fn:
                df = fn().reset_index()
                x_col = groupby[0] if len(groupby) == 1 else x_col
        except Exception:
            pass

    try:
        if chart_type in ("bar", "horizontal_bar"):
            return bar_chart(df, x=x_col, y=y_col, title=title,
                             orientation="h" if chart_type == "horizontal_bar" else "v",
                             color=color_col, color_map=color_map)
        elif chart_type == "line":
            return line_chart(df, x=x_col, y=y_col, title=title, color=color_col)
        elif chart_type in ("pie", "donut"):
            return pie_chart(df, names=x_col, values=y_col, title=title,
                             hole=0.52 if chart_type == "donut" else 0.0, color_map=color_map)
        elif chart_type == "scatter":
            return scatter_chart(df, x=x_col, y=y_col, title=title, color=color_col, color_map=color_map)
        elif chart_type == "heatmap":
            return heatmap_chart(df, x=x_col, y=color_col or "", values=y_col, title=title)
        elif chart_type == "treemap":
            return treemap_chart(df, path=groupby if groupby else [x_col], values=y_col, title=title)
        elif chart_type == "box":
            return box_chart(df, x=x_col, y=y_col, title=title, color=color_col, color_map=color_map)
        elif chart_type in ("grouped_bar", "stacked_bar"):
            return grouped_bar(df, x=x_col, y=y_col, color=color_col or "",
                               barmode="group" if chart_type == "grouped_bar" else "stack",
                               title=title, color_map=color_map)
        elif chart_type == "stacked_area":
            return stacked_area(df, x=x_col, y=y_col, color=color_col or "", title=title)
        elif chart_type == "table":
            cols = groupby + ([y_col] if y_col else [])
            return kpi_table(df[cols] if cols else df, title=title)
        else:
            return bar_chart(df, x=x_col, y=y_col, title=title)
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("Chart error [%s]: %s", chart_type, e)
        return None
