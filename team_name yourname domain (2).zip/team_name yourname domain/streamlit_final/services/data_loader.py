"""
services/data_loader.py — Cached Gold & Silver table loader from S3 parquet.

Uses storage_options (not filesystem=) to avoid PyArrow path-prefix mismatch
with s3fs on partitioned parquet tables.
"""
import os
import logging
import pandas as pd
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

BUCKET        = os.getenv("S3_BUCKET", "ecommerce-lakehouse-project-2026")
GOLD_PREFIX   = os.getenv("S3_GOLD_PREFIX", "gold")
SILVER_PREFIX = os.getenv("S3_SILVER_PREFIX", "silver")


def _get_storage_options() -> dict:
    """Build S3 storage_options dict from environment variables."""
    key    = os.getenv("AWS_ACCESS_KEY_ID", "")
    secret = os.getenv("AWS_SECRET_ACCESS_KEY", "")
    token  = os.getenv("AWS_SESSION_TOKEN", "")
    region = os.getenv("AWS_REGION", "ap-south-1")

    if not key or not secret:
        raise EnvironmentError(
            "AWS credentials missing — set AWS_ACCESS_KEY_ID and "
            "AWS_SECRET_ACCESS_KEY in your .env file."
        )

    opts = {
        "key":    key,
        "secret": secret,
        "client_kwargs": {"region_name": region},
    }
    if token:
        opts["token"] = token
    return opts


def _s3_path(layer: str, table: str) -> str:
    return f"s3://{BUCKET}/{layer}/{table}/"


@st.cache_data(ttl=3600, show_spinner=False)
def load_gold(table_name: str) -> pd.DataFrame:
    """Load a Gold-layer partitioned parquet table into a DataFrame."""
    path = _s3_path(GOLD_PREFIX, table_name)
    try:
        df = pd.read_parquet(path, storage_options=_get_storage_options())
        for col in df.select_dtypes(include=["object"]).columns:
            if "date" in col.lower():
                try:
                    df[col] = pd.to_datetime(df[col], errors="coerce")
                except Exception:
                    pass
        logger.info("Loaded gold/%s — %d rows", table_name, len(df))
        return df
    except Exception as e:
        logger.error("Failed to load gold/%s: %s", table_name, e)
        raise


@st.cache_data(ttl=3600, show_spinner=False)
def load_silver(table_name: str) -> pd.DataFrame:
    """Load a Silver-layer parquet table."""
    path = _s3_path(SILVER_PREFIX, table_name)
    try:
        df = pd.read_parquet(path, storage_options=_get_storage_options())
        logger.info("Loaded silver/%s — %d rows", table_name, len(df))
        return df
    except Exception as e:
        logger.error("Failed to load silver/%s: %s", table_name, e)
        raise


def load_all_gold() -> dict[str, pd.DataFrame]:
    """Load all 6 Gold tables. Returns dict keyed by table name."""
    tables = [
        "sales_summary", "customer_analytics", "product_performance",
        "inventory_health", "payment_summary", "review_analytics",
    ]
    return {t: load_gold(t) for t in tables}


def build_data_summary(tables: dict[str, pd.DataFrame], max_rows: int = 50) -> str:
    """
    Build a compact text summary of all tables for Claude context.
    Never sends raw rows — only aggregated statistics.
    """
    parts = []

    if "sales_summary" in tables:
        df = tables["sales_summary"]
        parts.append("=== SALES ===")
        parts.append(f"Total Net Revenue     : ${df['net_revenue'].sum():,.0f}")
        parts.append(f"Total Orders          : {df['total_orders'].sum():,}")
        parts.append(f"Avg Order Value       : ${df['avg_order_value'].mean():,.0f}")
        parts.append(f"Avg Fulfillment Days  : {df['avg_fulfillment_days'].mean():.1f}")
        rev_yr = df.groupby("order_year")["net_revenue"].sum().to_dict()
        parts.append(f"Revenue by Year       : {rev_yr}")

    if "customer_analytics" in tables:
        df = tables["customer_analytics"]
        parts.append("\n=== CUSTOMERS ===")
        parts.append(f"Total Customers       : {len(df):,}")
        parts.append(f"Avg Lifetime Value    : ${df['lifetime_value'].mean():,.0f}")
        parts.append(f"Segments              : {df['customer_segment'].value_counts().to_dict()}")
        parts.append(f"Countries             : {df['country'].value_counts().to_dict()}")
        parts.append(f"LTV by Segment        : {df.groupby('customer_segment')['lifetime_value'].mean().round(0).to_dict()}")
        parts.append(f"Status                : {df['customer_status'].value_counts().to_dict()}")

    if "product_performance" in tables:
        df = tables["product_performance"]
        parts.append("\n=== PRODUCTS ===")
        parts.append(f"Total Products        : {len(df):,}")
        parts.append(f"Revenue by Category   : {df.groupby('category')['revenue'].sum().sort_values(ascending=False).round(0).to_dict()}")
        parts.append(f"Profit by Category    : {df.groupby('category')['profit_estimate'].sum().sort_values(ascending=False).round(0).to_dict()}")
        margin = df.groupby("category").apply(
            lambda x: round(x["profit_estimate"].sum() / x["revenue"].sum() * 100, 1)
            if x["revenue"].sum() > 0 else 0
        ).to_dict()
        parts.append(f"Profit Margin % by Cat: {margin}")

    if "inventory_health" in tables:
        df = tables["inventory_health"]
        parts.append("\n=== INVENTORY ===")
        total = len(df)
        low   = int(df["low_stock_flag"].sum())
        parts.append(f"Total SKUs            : {total:,}")
        parts.append(f"Low Stock %           : {low/total*100:.1f}%  ({low:,} SKUs)")
        parts.append(f"Status Mix            : {df['inventory_status'].value_counts().to_dict()}")
        below_reorder = int((df["available_stock"] < df["reorder_point"]).sum())
        parts.append(f"Below Reorder Point   : {below_reorder:,} SKUs")
        parts.append(f"Low Stock by Country  : {df[df['low_stock_flag']].groupby('warehouse_country').size().to_dict()}")

    if "payment_summary" in tables:
        df = tables["payment_summary"]
        parts.append("\n=== PAYMENTS ===")
        total = df["transaction_count"].sum()
        suc   = df[df["payment_status"] == "Success"]["transaction_count"].sum()
        parts.append(f"Total Transactions    : {total:,}")
        parts.append(f"Success Rate          : {suc/total*100:.1f}%")
        parts.append(f"Status Breakdown      : {df.groupby('payment_status')['transaction_count'].sum().to_dict()}")
        parts.append(f"Volume by Method      : {df.groupby('payment_method')['transaction_count'].sum().sort_values(ascending=False).to_dict()}")
        parts.append(f"Avg Fraud by Method   : {df.groupby('payment_method')['avg_fraud_score'].mean().sort_values(ascending=False).round(3).to_dict()}")

    if "review_analytics" in tables:
        df = tables["review_analytics"]
        parts.append("\n=== REVIEWS ===")
        parts.append(f"Total Reviews         : {len(df):,}")
        parts.append(f"Avg Rating            : {df['avg_rating'].mean():.2f}/5.0")
        parts.append(f"Sentiment             : {df['sentiment'].value_counts().to_dict()}")
        parts.append(f"NPS                   : {df['nps_category'].value_counts().to_dict()}")
        parts.append(f"Rating Trend          : {df['rating_trend'].value_counts().to_dict()}")
        df_p = df.drop_duplicates("product_id")
        parts.append(f"Avg Rating by Category: {df_p.groupby('category')['avg_rating'].mean().sort_values(ascending=False).round(2).to_dict()}")

    return "\n".join(parts)
