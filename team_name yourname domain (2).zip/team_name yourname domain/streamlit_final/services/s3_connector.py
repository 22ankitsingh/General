"""
services/s3_connector.py — S3 filesystem connection with credential management.
"""
import os
import logging
import s3fs
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

_fs_cache: s3fs.S3FileSystem | None = None


def get_s3_filesystem(force_refresh: bool = False) -> s3fs.S3FileSystem:
    """Return a cached s3fs filesystem. Refresh on demand (e.g. after token rotation)."""
    global _fs_cache
    if _fs_cache is None or force_refresh:
        key   = os.getenv("AWS_ACCESS_KEY_ID", "")
        secret= os.getenv("AWS_SECRET_ACCESS_KEY", "")
        token = os.getenv("AWS_SESSION_TOKEN", "")
        region= os.getenv("AWS_REGION", "ap-south-1")

        if not key or not secret:
            raise EnvironmentError(
                "AWS credentials not found. "
                "Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY in .env"
            )

        _fs_cache = s3fs.S3FileSystem(
            key=key,
            secret=secret,
            token=token if token else None,
            client_kwargs={"region_name": region},
        )
        logger.info("S3 filesystem initialised (region=%s)", region)
    return _fs_cache


def test_s3_connection() -> tuple[bool, str]:
    """Verify S3 connectivity. Returns (success, message)."""
    try:
        fs = get_s3_filesystem()
        bucket = os.getenv("S3_BUCKET", "ecommerce-lakehouse-project-2026")
        prefix = os.getenv("S3_GOLD_PREFIX", "gold")
        items = fs.ls(f"{bucket}/{prefix}/", detail=False)
        return True, f"Connected — {len(items)} gold table(s) found"
    except EnvironmentError as e:
        return False, f"Config error: {e}"
    except Exception as e:
        return False, f"Connection error: {e}"


def refresh_credentials() -> None:
    """Force credential refresh (call after updating .env with new session token)."""
    load_dotenv(override=True)
    get_s3_filesystem(force_refresh=True)
    logger.info("S3 credentials refreshed")
