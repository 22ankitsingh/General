"""
config.py — Central configuration for Ecommerce Analytics Copilot.
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ── AWS ────────────────────────────────────────────────
AWS_ACCESS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID", "")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY", "")
AWS_SESSION_TOKEN     = os.getenv("AWS_SESSION_TOKEN", "")
AWS_REGION            = os.getenv("AWS_REGION", "ap-south-1")
S3_BUCKET             = os.getenv("S3_BUCKET", "ecommerce-lakehouse-project-2026")
S3_GOLD_PREFIX        = os.getenv("S3_GOLD_PREFIX", "gold")
S3_SILVER_PREFIX      = os.getenv("S3_SILVER_PREFIX", "silver")

# ── OpenAI ─────────────────────────────────────────────
OPENAI_API_KEY  = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL    = os.getenv("OPENAI_MODEL", "gpt-4o")
OPENAI_MAX_TOKENS = 2048

# ── App ────────────────────────────────────────────────
APP_TITLE     = os.getenv("APP_TITLE", "Ecommerce Analytics Copilot")
APP_CACHE_TTL = int(os.getenv("APP_CACHE_TTL", "3600"))

# ── S3 path helpers ────────────────────────────────────
def gold_path(table: str) -> str:
    return f"s3://{S3_BUCKET}/{S3_GOLD_PREFIX}/{table}/"

def silver_path(table: str) -> str:
    return f"s3://{S3_BUCKET}/{S3_SILVER_PREFIX}/{table}/"

# ── Dark Pro color palette ─────────────────────────────
COLORS = {
    "primary":   "#3b82f6",
    "secondary": "#06b6d4",
    "success":   "#10b981",
    "warning":   "#f59e0b",
    "danger":    "#ef4444",
    "purple":    "#8b5cf6",
    "pink":      "#ec4899",
    "orange":    "#f97316",
    "bg":        "#0a0e1a",
    "card":      "#111827",
    "border":    "#1e293b",
    "text":      "#f1f5f9",
    "muted":     "#64748b",
}

# 8-color chart palette — vivid on dark background
CHART_COLORS = [
    "#3b82f6", "#06b6d4", "#10b981", "#f59e0b",
    "#8b5cf6", "#ef4444", "#f97316", "#ec4899",
]

SEGMENT_COLORS = {
    "Platinum": "#8b5cf6",
    "Gold":     "#f59e0b",
    "Silver":   "#94a3b8",
    "Bronze":   "#f97316",
}

PAYMENT_STATUS_COLORS = {
    "Success":  "#10b981",
    "Failed":   "#ef4444",
    "Refunded": "#f59e0b",
    "Pending":  "#64748b",
}

SENTIMENT_COLORS = {
    "Positive": "#10b981",
    "Neutral":  "#64748b",
    "Negative": "#ef4444",
}

NPS_COLORS = {
    "Promoter":  "#10b981",
    "Passive":   "#f59e0b",
    "Detractor": "#ef4444",
}

INVENTORY_STATUS_COLORS = {
    "in_stock":      "#10b981",
    "low_stock":     "#f59e0b",
    "out_of_stock":  "#ef4444",
}

# ── Plotly dark theme settings ─────────────────────────
PLOTLY_TEMPLATE = "plotly_dark"
PLOTLY_BG       = "#111827"
PLOTLY_PAPER_BG = "#111827"
PLOTLY_GRID     = "#1e293b"
PLOTLY_FONT     = {"color": "#94a3b8", "family": "Inter, sans-serif", "size": 12}
