"""
ai/claude_client.py — OpenAI GPT-4o wrapper (drop-in replacement for Claude client).
Function names preserved so dashboard_engine.py needs no changes.
"""
import os
import json
import logging
import re
from dotenv import load_dotenv
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

load_dotenv()
logger = logging.getLogger(__name__)

_client = None


def get_client():
    global _client
    if _client is None:
        from openai import OpenAI
        api_key = os.getenv("OPENAI_API_KEY", "")
        if not api_key:
            raise EnvironmentError("OPENAI_API_KEY not set in .env")
        _client = OpenAI(api_key=api_key)
    return _client


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    retry=retry_if_exception_type(Exception),
)
def call_claude(
    user_message: str,
    system_prompt: str = "",
    conversation_history: list | None = None,
    max_tokens: int = 2048,
) -> str:
    """Call GPT-4o and return text response."""
    from openai import RateLimitError, APIConnectionError
    model = os.getenv("OPENAI_MODEL", "gpt-4o")
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    for msg in (conversation_history or []):
        if msg.get("role") in ("user", "assistant"):
            messages.append({"role": msg["role"], "content": msg["content"]})
    messages.append({"role": "user", "content": user_message})

    try:
        client = get_client()
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=0.3,
        )
        return response.choices[0].message.content
    except Exception as e:
        logger.error("OpenAI API error: %s", e)
        raise


def call_claude_json(
    user_message: str,
    system_prompt: str = "",
    conversation_history: list | None = None,
) -> dict:
    """Call GPT-4o and parse response as JSON."""
    raw = call_claude(user_message, system_prompt, conversation_history)
    text = raw.strip()
    # Strip ```json ... ``` fences
    if text.startswith("```"):
        lines = text.split("\n")
        text = "\n".join(lines[1:-1] if lines[-1].startswith("```") else lines[1:])
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]+\}", text)
        if match:
            try:
                return json.loads(match.group())
            except Exception:
                pass
        logger.warning("JSON parse failed. Raw: %s", raw[:400])
        raise ValueError(f"GPT-4o did not return valid JSON. Got: {raw[:300]}")
