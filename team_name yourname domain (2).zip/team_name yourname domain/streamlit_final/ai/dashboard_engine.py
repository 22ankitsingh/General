"""ai/dashboard_engine.py"""
import streamlit as st
import pandas as pd
from components.chart_factory import render_chart_spec, display_chart
from components.kpi_cards import render_kpi_row
from ai.claude_client import call_claude_json
from ai.prompt_templates import SYSTEM_PROMPT_COPILOT, build_analysis_prompt, build_followup_prompt
from services.data_loader import build_data_summary
import json, logging
logger = logging.getLogger(__name__)

def run_analysis(question, all_data, conversation_history=None):
    ctx = build_data_summary(all_data)
    prev = None
    for m in reversed(conversation_history or []):
        if m["role"]=="assistant":
            try: prev=json.loads(m["content"]).get("intent")
            except: pass
            break
    prompt = build_followup_prompt(question, ctx, prev) if prev else build_analysis_prompt(question, ctx)
    return call_claude_json(user_message=prompt, system_prompt=SYSTEM_PROMPT_COPILOT,
                            conversation_history=conversation_history)

def render_dashboard_spec(spec, all_data):
    if not spec: st.warning("No spec received."); return

    summary = spec.get("executive_summary","")
    if summary:
        st.markdown(f'<div class="exec-summary"><b>Executive Summary</b><br>{summary}</div>',
                    unsafe_allow_html=True)

    kpis = spec.get("kpis",[])
    if kpis:
        st.markdown('<div class="section-header">Key Performance Indicators</div>', unsafe_allow_html=True)
        for i in range(0, len(kpis), 5): render_kpi_row(kpis[i:i+5])
        st.markdown("---")

    charts = spec.get("charts",[])
    if charts:
        st.markdown('<div class="section-header">Visualizations</div>', unsafe_allow_html=True)
        for i in range(0, len(charts), 2):
            chunk=charts[i:i+2]; cols=st.columns(len(chunk))
            for col,cs in zip(cols,chunk):
                with col:
                    fig=render_chart_spec(cs, all_data)
                    if fig: display_chart(fig)
        st.markdown("---")

    insights = spec.get("insights",[])
    if insights:
        st.markdown('<div class="section-header">Business Insights</div>', unsafe_allow_html=True)
        for ins in insights: st.markdown(f'<div class="insight-card">💡 {ins}</div>', unsafe_allow_html=True)
        st.markdown("---")

    recs = spec.get("recommendations",[])
    if recs:
        st.markdown('<div class="section-header">Recommended Actions</div>', unsafe_allow_html=True)
        cls={"High":"rec-high","Medium":"rec-medium","Low":"rec-low"}
        ico={"High":"🔴","Medium":"🟡","Low":"🟢"}
        for r in recs:
            if isinstance(r,dict):
                p=r.get("priority","Medium"); act=r.get("action",""); imp=r.get("expected_impact","")
                imp_html=f'<div style="color:#64748b;font-size:0.78rem;margin-top:3px">{imp}</div>' if imp else ""
                st.markdown(f'<div class="{cls.get(p,"rec-medium")}"><b>{ico.get(p,"⚪")} [{p}]</b> {act}{imp_html}</div>',
                            unsafe_allow_html=True)
