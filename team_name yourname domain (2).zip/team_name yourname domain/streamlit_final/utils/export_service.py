"""
utils/export_service.py — PNG and PDF export for dashboards.
"""
import io
import logging
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

logger = logging.getLogger(__name__)


def fig_to_png_bytes(fig: go.Figure) -> bytes | None:
    """Convert a Plotly figure to PNG bytes using kaleido."""
    try:
        return fig.to_image(format="png", width=1200, height=600, scale=2)
    except Exception as e:
        logger.warning("PNG export failed (kaleido installed?): %s", e)
        return None


def download_chart_button(fig: go.Figure, filename: str = "chart.png", label: str = "⬇️ PNG") -> None:
    """Render a Streamlit download button for a Plotly chart PNG."""
    img_bytes = fig_to_png_bytes(fig)
    if img_bytes:
        st.download_button(
            label=label,
            data=img_bytes,
            file_name=filename,
            mime="image/png",
            key=f"dl_{filename}",
        )
    else:
        st.caption("Install `kaleido` for PNG export: `pip install kaleido`")


def export_dashboard_pdf(title: str, kpis: list[dict], insights: list[str],
                         recommendations: list[dict]) -> bytes | None:
    """
    Generate a PDF report using fpdf2.
    Returns PDF bytes or None on failure.
    """
    try:
        from fpdf import FPDF

        class PDF(FPDF):
            def header(self):
                self.set_font("Helvetica", "B", 14)
                self.set_text_color(26, 26, 46)
                self.cell(0, 12, title, ln=True, align="C")
                self.set_draw_color(52, 152, 219)
                self.set_line_width(0.5)
                self.line(10, self.get_y(), 200, self.get_y())
                self.ln(4)

            def footer(self):
                self.set_y(-15)
                self.set_font("Helvetica", "I", 8)
                self.set_text_color(150)
                self.cell(0, 10, f"Page {self.page_no()}", align="C")

        pdf = PDF()
        pdf.add_page()
        pdf.set_auto_page_break(auto=True, margin=15)

        # KPIs
        pdf.set_font("Helvetica", "B", 12)
        pdf.set_text_color(26, 26, 46)
        pdf.cell(0, 10, "Key Performance Indicators", ln=True)
        pdf.set_font("Helvetica", "", 10)
        for kpi in kpis:
            pdf.set_text_color(100, 100, 100)
            pdf.cell(80, 8, kpi.get("label", ""), border=0)
            pdf.set_text_color(26, 26, 46)
            pdf.set_font("Helvetica", "B", 10)
            pdf.cell(60, 8, str(kpi.get("value", "")), ln=True)
            pdf.set_font("Helvetica", "", 10)
        pdf.ln(4)

        # Insights
        if insights:
            pdf.set_font("Helvetica", "B", 12)
            pdf.set_text_color(26, 26, 46)
            pdf.cell(0, 10, "Business Insights", ln=True)
            pdf.set_font("Helvetica", "", 10)
            pdf.set_text_color(60, 60, 60)
            for insight in insights:
                pdf.multi_cell(0, 7, f"• {insight}")
            pdf.ln(4)

        # Recommendations
        if recommendations:
            pdf.set_font("Helvetica", "B", 12)
            pdf.set_text_color(26, 26, 46)
            pdf.cell(0, 10, "Recommended Actions", ln=True)
            pdf.set_font("Helvetica", "", 10)
            for rec in recommendations:
                if isinstance(rec, dict):
                    p   = rec.get("priority","")
                    act = rec.get("action","")
                    pdf.set_text_color(60, 60, 60)
                    pdf.multi_cell(0, 7, f"[{p}] {act}")
                else:
                    pdf.multi_cell(0, 7, f"• {rec}")

        return bytes(pdf.output())
    except ImportError:
        logger.warning("fpdf2 not installed — install with: pip install fpdf2")
        return None
    except Exception as e:
        logger.error("PDF generation failed: %s", e)
        return None


def download_pdf_button(title: str, kpis: list, insights: list, recommendations: list,
                        filename: str = "dashboard_report.pdf") -> None:
    pdf_bytes = export_dashboard_pdf(title, kpis, insights, recommendations)
    if pdf_bytes:
        st.download_button(
            label="⬇️ Export PDF Report",
            data=pdf_bytes,
            file_name=filename,
            mime="application/pdf",
            key=f"pdf_{filename}",
        )
    else:
        st.caption("Install `fpdf2` for PDF export: `pip install fpdf2`")
