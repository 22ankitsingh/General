"""
utils/session_manager.py — Streamlit session state helpers.
"""
import streamlit as st
import json
from datetime import datetime


def init_session() -> None:
    """Initialise all required session state keys."""
    defaults = {
        "chat_history":        [],   # list of {role, content, timestamp}
        "last_spec":           None, # last Claude dashboard spec
        "last_intent":         None,
        "data_loaded":         False,
        "cached_tables":       {},
        "dark_mode":           True,   # default: dark (matches style.css defaults)
        "refresh_counter":     0,
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val


def add_message(role: str, content: str, spec: dict | None = None) -> None:
    """Append a message to chat history."""
    st.session_state.chat_history.append({
        "role":      role,
        "content":   content,
        "spec":      spec,
        "timestamp": datetime.now().strftime("%H:%M"),
    })


def get_api_history() -> list[dict]:
    """Return conversation history in Anthropic messages format (no spec)."""
    return [
        {"role": m["role"], "content": m["content"]}
        for m in st.session_state.chat_history
        if m["role"] in ("user", "assistant")
    ]


def clear_chat() -> None:
    st.session_state.chat_history = []
    st.session_state.last_spec    = None
    st.session_state.last_intent  = None


def toggle_dark_mode() -> None:
    st.session_state.dark_mode = not st.session_state.dark_mode


def increment_refresh() -> None:
    """Bust data cache by incrementing counter (clears @st.cache_data)."""
    st.session_state.refresh_counter += 1
    from services.data_loader import load_gold, load_silver
    load_gold.clear()
    load_silver.clear()
