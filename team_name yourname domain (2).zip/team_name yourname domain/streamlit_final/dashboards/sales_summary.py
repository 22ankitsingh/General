"""dashboards/sales_summary.py"""
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from components.kpi_cards import render_kpi_row
from components.filters import sales_filters, apply_filters
from components.chart_factory import display_chart, bar_chart, line_chart, grouped_bar, _lay, _is_dark
from config import CHART_COLORS


def render(df_raw):
    st.markdown('<div class="page-title">📈 Sales Summary</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">Revenue trends, order volumes and fulfilment performance</div>', unsafe_allow_html=True)

    filters = sales_filters(df_raw)
    df = apply_filters(df_raw, filters, date_col="order_date")
    if df.empty:
        st.warning("No data matches filters.")
        return

    render_kpi_row([
        {"icon": "💰", "label": "Net Revenue",        "value": f"${df['net_revenue'].sum():,.0f}",          "delta_type": "positive"},
        {"icon": "🛒", "label": "Total Orders",        "value": f"{int(df['total_orders'].sum()):,}"},
        {"icon": "📊", "label": "Avg Order Value",     "value": f"${df['avg_order_value'].mean():,.0f}"},
        {"icon": "🏷️", "label": "Total Discounts",    "value": f"${df['total_discounts'].sum():,.0f}",      "delta_type": "negative"},
        {"icon": "🚚", "label": "Avg Fulfilment Days", "value": f"{df['avg_fulfillment_days'].mean():.1f}d"},
    ])
    st.markdown("---")

    # Row 1
    c1, c2 = st.columns(2)
    with c1:
        d = df.copy()
        d["order_date"] = pd.to_datetime(d["order_date"], errors="coerce")
        m = d.groupby(d["order_date"].dt.to_period("M").astype(str))["net_revenue"].sum().reset_index()
        m.columns = ["month", "net_revenue"]
        fig = line_chart(m, x="month", y="net_revenue", title="Monthly Net Revenue")
        fig.update_traces(fill="tozeroy", fillcolor="rgba(59,130,246,0.07)", line_color=CHART_COLORS[0])
        display_chart(fig)
    with c2:
        if "order_year" in df.columns:
            yr = df.groupby("order_year")["total_orders"].sum().reset_index()
            display_chart(bar_chart(yr, x="order_year", y="total_orders", title="Orders by Year"))

    # Row 2
    c3, c4 = st.columns(2)
    with c3:
        if "order_year" in df.columns:
            comp = df.groupby("order_year")[["gross_revenue", "total_discounts", "net_revenue"]].sum().reset_index()
            comp_m = comp.melt(id_vars="order_year", var_name="metric", value_name="amount")
            display_chart(grouped_bar(comp_m, x="order_year", y="amount", color="metric", title="Revenue vs Discounts"))
    with c4:
        d2 = df.copy()
        d2["order_date"] = pd.to_datetime(d2["order_date"], errors="coerce")
        m2 = d2.groupby(d2["order_date"].dt.to_period("M").astype(str))["avg_order_value"].mean().reset_index()
        m2.columns = ["month", "aov"]
        fig = line_chart(m2, x="month", y="aov", title="Monthly Avg Order Value")
        fig.update_traces(line_color=CHART_COLORS[1])
        display_chart(fig)

    # Row 3
    c5, c6 = st.columns(2)
    with c5:
        if "order_year" in df.columns and "order_month" in df.columns:
            heat = df.pivot_table(index="order_month", columns="order_year", values="net_revenue", aggfunc="sum")
            fig = go.Figure(go.Heatmap(
                z=heat.values,
                x=[str(c) for c in heat.columns],
                y=[f"M{r}" for r in heat.index],
                colorscale=([[0, "#0d1117"], [0.5, "#1e3a5f"], [1, "#3b82f6"]]
                            if _is_dark() else
                            [[0, "#f8fafc"], [0.5, "#bfdbfe"], [1, "#2563eb"]]),
                hovertemplate="<b>Year %{x} · M%{y}</b><br>Revenue: $%{z:,.0f}<extra></extra>",
            ))
            _lay(fig, "Revenue Heatmap Month × Year")
            display_chart(fig)
    with c6:
        d3 = df.copy()
        d3["order_date"] = pd.to_datetime(d3["order_date"], errors="coerce")
        m3 = d3.groupby(d3["order_date"].dt.to_period("M").astype(str))["avg_fulfillment_days"].mean().reset_index()
        m3.columns = ["month", "days"]
        fig = line_chart(m3, x="month", y="days", title="Avg Fulfilment Days")
        fig.update_traces(line_color=CHART_COLORS[2])
        fig.add_hline(y=5, line_dash="dash", line_color="#ef4444",
                      annotation_text="SLA 5d", annotation_font_color="#ef4444")
        display_chart(fig)

    # Row 4
    c7, c8 = st.columns(2)
    with c7:
        if "order_year" in df.columns:
            ship = df.groupby("order_year")["shipping_cost"].sum().reset_index()
            fig = bar_chart(ship, x="order_year", y="shipping_cost", title="Shipping Cost by Year")
            fig.update_traces(marker_color=CHART_COLORS[3])
            display_chart(fig)
    with c8:
        if "order_year" in df.columns:
            gn = df.groupby("order_year")[["gross_revenue", "net_revenue"]].sum().reset_index()
            gn_m = gn.melt(id_vars="order_year", var_name="type", value_name="revenue")
            display_chart(grouped_bar(gn_m, x="order_year", y="revenue", color="type", title="Gross vs Net Revenue"))
