"""dashboards/inventory_health.py"""
import streamlit as st
from components.kpi_cards import render_kpi_row, render_alert_banner
from components.filters import inventory_filters, apply_filters
from components.chart_factory import display_chart, bar_chart, pie_chart, scatter_chart, kpi_table, grouped_bar, _lay
from config import INVENTORY_STATUS_COLORS, CHART_COLORS


def render(df_raw):
    st.markdown('<div class="page-title">🏭 Inventory Health</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">Stock levels, reorder alerts and warehouse distribution</div>', unsafe_allow_html=True)

    filters = inventory_filters(df_raw)
    df = apply_filters(df_raw, filters)
    if df.empty:
        st.warning("No data.")
        return

    total   = len(df)
    low     = int(df["low_stock_flag"].sum())
    out     = int((df["inventory_status"] == "out_of_stock").sum())
    below   = int((df["available_stock"] < df["reorder_point"]).sum())
    inv_val = df["inventory_value"].sum()

    if out > 0:
        render_alert_banner(f"{out:,} SKUs OUT OF STOCK — immediate action required", "danger")
    if low > 50:
        render_alert_banner(f"{low:,} SKUs at LOW STOCK threshold", "warning")

    render_kpi_row([
        {"icon": "📦", "label": "Total SKUs",      "value": f"{total:,}"},
        {"icon": "⚠️", "label": "Low Stock",       "value": f"{low:,}",   "delta_type": "negative" if low > 100 else "neutral"},
        {"icon": "🚫", "label": "Out of Stock",    "value": f"{out:,}",   "delta_type": "negative" if out > 0 else "neutral"},
        {"icon": "📉", "label": "Below Reorder",   "value": f"{below:,}", "delta_type": "negative" if below > 50 else "neutral"},
        {"icon": "💰", "label": "Inventory Value", "value": f"${inv_val:,.0f}", "delta_type": "positive"},
    ])
    st.markdown("---")

    c1, c2 = st.columns(2)
    with c1:
        s = df["inventory_status"].value_counts().reset_index()
        s.columns = ["status", "count"]
        display_chart(pie_chart(s, names="status", values="count", title="Inventory Status Mix", color_map=INVENTORY_STATUS_COLORS))
    with c2:
        lc = df[df["low_stock_flag"]].groupby("warehouse_country").size().reset_index(name="count")
        fig = bar_chart(lc, x="count", y="warehouse_country", title="Low Stock SKUs by Country", orientation="h")
        fig.update_traces(marker_color=CHART_COLORS[3])
        display_chart(fig)

    c3, c4 = st.columns(2)
    with c3:
        bl = df[df["available_stock"] < df["reorder_point"]].groupby("warehouse_country").size().reset_index(name="count")
        fig = bar_chart(bl, x="count", y="warehouse_country", title="Below Reorder Point by Country", orientation="h")
        fig.update_traces(marker_color=CHART_COLORS[4])
        display_chart(fig)
    with c4:
        vc = df.groupby("warehouse_country")["inventory_value"].sum().reset_index().sort_values("inventory_value", ascending=True)
        display_chart(bar_chart(vc, x="inventory_value", y="warehouse_country",
                                title="Inventory Value by Country", orientation="h"))

    c5, c6 = st.columns(2)
    with c5:
        samp = df.sample(min(400, len(df)), random_state=42)
        fig = scatter_chart(samp, x="available_stock", y="reorder_point",
                            title="Available Stock vs Reorder Point",
                            color="inventory_status", color_map=INVENTORY_STATUS_COLORS)
        mn = min(df["available_stock"].min(), df["reorder_point"].min())
        mx = max(df["available_stock"].max(), df["reorder_point"].max())
        fig.add_shape(type="line", x0=mn, y0=mn, x1=mx, y1=mx,
                      line=dict(color="#ef4444", dash="dash", width=1.5))
        display_chart(fig)
    with c6:
        stk = df.groupby(["warehouse_country", "inventory_status"]).size().reset_index(name="count")
        display_chart(grouped_bar(
            stk, x="warehouse_country", y="count", color="inventory_status",
            barmode="stack", color_map=INVENTORY_STATUS_COLORS,
            title="Status Distribution by Country",
        ))

    st.markdown('<div class="section-header">Critical SKUs — Lowest Available Stock</div>', unsafe_allow_html=True)
    crit = df[df["inventory_status"].isin(["out_of_stock", "low_stock"])].nsmallest(15, "available_stock")[
        ["product_name", "warehouse_country", "inventory_status", "available_stock", "reorder_point", "inventory_value"]
    ].reset_index(drop=True)
    if not crit.empty:
        crit["inventory_value"] = crit["inventory_value"].map("${:,.0f}".format)
        display_chart(kpi_table(crit, height=440))
