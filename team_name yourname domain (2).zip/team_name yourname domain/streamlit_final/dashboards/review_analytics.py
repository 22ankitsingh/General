"""dashboards/review_analytics.py"""
import pandas as pd
import streamlit as st
from components.kpi_cards import render_kpi_row
from components.filters import review_filters, apply_filters
from components.chart_factory import display_chart, bar_chart, pie_chart, line_chart, kpi_table, grouped_bar
from config import SENTIMENT_COLORS, NPS_COLORS, CHART_COLORS

TREND_COLORS = {"Improving": "#10b981", "Stable": "#2563eb", "Declining": "#ef4444"}


def render(df_raw):
    st.markdown('<div class="page-title">⭐ Review Analytics</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">Ratings, sentiment, NPS and product review trends</div>', unsafe_allow_html=True)

    filters = review_filters(df_raw)
    df = apply_filters(df_raw, filters, date_col="review_date")
    if df.empty:
        st.warning("No data.")
        return

    df_rev  = df.drop_duplicates("review_id") if "review_id" in df.columns else df
    df_prod = df.drop_duplicates("product_id")
    tot  = len(df_rev)
    avg  = df["avg_rating"].mean()
    prom = df_rev[df_rev["nps_category"] == "Promoter"].shape[0] / len(df_rev) * 100 if len(df_rev) > 0 else 0
    pos  = df["positive_rate_pct"].mean()
    neg  = df["negative_rate_pct"].mean()

    render_kpi_row([
        {"icon": "📝", "label": "Reviews",    "value": f"{tot:,}"},
        {"icon": "⭐", "label": "Avg Rating", "value": f"{avg:.2f}/5"},
        {"icon": "😊", "label": "Promoter %", "value": f"{prom:.1f}%", "delta_type": "positive" if prom > 50 else "negative"},
        {"icon": "👍", "label": "Positive %", "value": f"{pos:.1f}%",  "delta_type": "positive"},
        {"icon": "👎", "label": "Negative %", "value": f"{neg:.1f}%",  "delta_type": "negative" if neg > 30 else "neutral"},
    ])
    st.markdown("---")


    c1, c2 = st.columns(2)
    with c1:
        cr = df_prod.groupby("category")["avg_rating"].mean().reset_index().sort_values("avg_rating", ascending=True)
        fig = bar_chart(cr, x="avg_rating", y="category", title="Avg Rating by Category", orientation="h")
        fig.update_traces(marker=dict(color=cr["avg_rating"], colorscale="RdYlGn", cmin=1, cmax=5, showscale=False))
        display_chart(fig)
    with c2:
        sent = df_rev["sentiment"].value_counts().reset_index()
        sent.columns = ["s", "c"]
        display_chart(pie_chart(sent, names="s", values="c", title="Sentiment Distribution", color_map=SENTIMENT_COLORS))

    c3, c4 = st.columns(2)
    with c3:
        nps = df_rev["nps_category"].value_counts().reset_index()
        nps.columns = ["n", "c"]
        display_chart(pie_chart(nps, names="n", values="c", title="NPS Category Distribution", color_map=NPS_COLORS))
    with c4:
        tr = df_rev["rating_trend"].value_counts().reset_index()
        tr.columns = ["t", "c"]
        display_chart(pie_chart(tr, names="t", values="c", title="Rating Trend Categories", color_map=TREND_COLORS))

    c5, c6 = st.columns(2)
    with c5:
        stars = pd.DataFrame({
            "Stars": ["5★", "4★", "3★", "2★", "1★"],
            "Count": [int(df["star_5_count"].sum()), int(df["star_4_count"].sum()),
                      int(df["star_3_count"].sum()), int(df["star_2_count"].sum()),
                      int(df["star_1_count"].sum())],
        })
        fig = bar_chart(stars, x="Stars", y="Count", title="Star Rating Distribution")
        fig.update_traces(marker_color=[CHART_COLORS[2], "#27ae60", CHART_COLORS[3], CHART_COLORS[5], "#991b1b"])
        display_chart(fig)
    with c6:
        d = df_rev.copy()
        d["review_date"] = pd.to_datetime(d["review_date"], errors="coerce")
        m = d.groupby(d["review_date"].dt.to_period("M").astype(str))["rating"].mean().reset_index()
        m.columns = ["month", "avg"]
        fig = line_chart(m, x="month", y="avg", title="Monthly Avg Rating Trend")
        fig.update_traces(line_color=CHART_COLORS[1])
        fig.add_hline(y=3.0, line_dash="dash", line_color="#ef4444",
                      annotation_text="3.0 threshold", annotation_font_color="#ef4444")
        display_chart(fig)

    c7, c8 = st.columns(2)
    with c7:
        t10 = df_prod.nlargest(10, "avg_rating")[["product_name", "category", "avg_rating"]].sort_values("avg_rating")
        display_chart(bar_chart(t10, x="avg_rating", y="product_name", title="Top 10 Highest Rated Products",
                                orientation="h", color="category"))
    with c8:
        b10 = df_prod.nsmallest(10, "avg_rating")[["product_name", "category", "avg_rating"]].sort_values("avg_rating", ascending=False)
        display_chart(bar_chart(b10, x="avg_rating", y="product_name", title="10 Lowest Rated Products",
                                orientation="h", color="category"))

    c9, c10 = st.columns(2)
    with c9:
        sc = df_rev.groupby(["category", "sentiment"]).size().reset_index(name="count")
        display_chart(grouped_bar(
            sc, x="category", y="count", color="sentiment",
            barmode="stack", color_map=SENTIMENT_COLORS,
            title="Sentiment by Category",
        ))
    with c10:
        ns = df_rev.groupby(["customer_segment", "nps_category"]).size().reset_index(name="count")
        display_chart(grouped_bar(
            ns, x="customer_segment", y="count", color="nps_category",
            barmode="group", color_map=NPS_COLORS,
            title="NPS by Customer Segment",
        ))

    c11, c12 = st.columns(2)
    with c11:
        ctry = df_rev["country"].value_counts().reset_index()
        ctry.columns = ["country", "count"]
        display_chart(bar_chart(ctry, x="country", y="count", title="Reviews by Country", color="country"))
    with c12:
        ver = df_rev["verified_purchase"].value_counts().reset_index()
        ver.columns = ["v", "c"]
        ver["v"] = ver["v"].map({True: "Verified", False: "Unverified",
                                  "true": "Verified", "false": "Unverified"}).fillna("Unknown")
        display_chart(pie_chart(ver, names="v", values="c", title="Verified vs Unverified Reviews",
                                color_map={"Verified": CHART_COLORS[2], "Unverified": CHART_COLORS[3]}))
