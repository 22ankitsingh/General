"""dashboards/customer_analytics.py"""
import streamlit as st
from components.kpi_cards import render_kpi_row
from components.filters import customer_filters, apply_filters
from components.chart_factory import (
    display_chart, bar_chart, pie_chart, scatter_chart,
    heatmap_chart, box_chart, kpi_table,
)
from config import SEGMENT_COLORS, CHART_COLORS


def render(df_raw):
    st.markdown('<div class="page-title">👥 Customer Analytics</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">Lifetime value, segments, geography and behaviour</div>', unsafe_allow_html=True)

    filters = customer_filters(df_raw)
    df = apply_filters(df_raw, filters)
    if df.empty:
        st.warning("No data.")
        return

    render_kpi_row([
        {"icon": "👥", "label": "Total Customers", "value": f"{len(df):,}"},
        {"icon": "💰", "label": "Avg LTV",         "value": f"${df['lifetime_value'].mean():,.0f}", "delta_type": "positive"},
        {"icon": "🛒", "label": "Avg Orders",      "value": f"{df['total_orders'].mean():.1f}"},
        {"icon": "💳", "label": "Avg Order Value", "value": f"${df['avg_order_value'].mean():,.0f}"},
        {"icon": "⭐", "label": "Avg Loyalty Pts", "value": f"{df['loyalty_points'].mean():,.0f}"},
    ])
    st.markdown("---")

    c1, c2 = st.columns(2)
    with c1:
        seg = df["customer_segment"].value_counts().reset_index()
        seg.columns = ["segment", "count"]
        display_chart(pie_chart(seg, names="segment", values="count", title="Segment Mix", color_map=SEGMENT_COLORS))
    with c2:
        ltv = df.groupby("customer_segment")["lifetime_value"].mean().reset_index().sort_values("lifetime_value")
        display_chart(bar_chart(ltv, x="lifetime_value", y="customer_segment",
                                title="Avg LTV by Segment", orientation="h",
                                color="customer_segment", color_map=SEGMENT_COLORS))

    c3, c4 = st.columns(2)
    with c3:
        ltvc = df.groupby("country")["lifetime_value"].mean().reset_index().sort_values("lifetime_value")
        display_chart(bar_chart(ltvc, x="lifetime_value", y="country",
                                title="Avg LTV by Country", orientation="h"))
    with c4:
        display_chart(heatmap_chart(df, x="customer_segment", y="country",
                                    values="lifetime_value", title="LTV Heatmap by Country × Segment"))

    c5, c6 = st.columns(2)
    with c5:
        pay = df["preferred_payment_method"].value_counts().reset_index()
        pay.columns = ["method", "count"]
        display_chart(pie_chart(pay, names="method", values="count", title="Preferred Payment Method"))
    with c6:
        customer_status = df["customer_status"].value_counts().reset_index()
        customer_status.columns = ["status", "count"]
        display_chart(pie_chart(customer_status, names="status", values="count", title="Customer Status"))

    c7, c8 = st.columns(2)
    with c7:
        display_chart(box_chart(df, x="customer_segment", y="lifetime_value",
                                title="LTV Distribution by Segment",
                                color="customer_segment", color_map=SEGMENT_COLORS))
    with c8:
        s = df.sample(min(500, len(df)), random_state=42)
        display_chart(scatter_chart(s, x="annual_income", y="lifetime_value",
                                    title="Income vs LTV",
                                    color="customer_segment", color_map=SEGMENT_COLORS))

    st.markdown('<div class="section-header">Top 20 Customers by LTV</div>', unsafe_allow_html=True)
    top = df.nlargest(20, "lifetime_value")[
        ["customer_name", "customer_segment", "country", "lifetime_value", "total_orders", "loyalty_points"]
    ].reset_index(drop=True)
    top["lifetime_value"] = top["lifetime_value"].map("${:,.0f}".format)
    display_chart(kpi_table(top, height=520))
