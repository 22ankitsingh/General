"""dashboards/payment_summary.py"""
import pandas as pd
import streamlit as st
from components.kpi_cards import render_kpi_row, render_alert_banner
from components.filters import payment_filters, apply_filters
from components.chart_factory import display_chart, bar_chart, pie_chart, line_chart, grouped_bar
from config import PAYMENT_STATUS_COLORS, CHART_COLORS


def render(df_raw):
    st.markdown('<div class="page-title">💳 Payment Summary</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">Transaction volumes, success rates, fraud scores and trends</div>', unsafe_allow_html=True)

    filters = payment_filters(df_raw)
    df = apply_filters(df_raw, filters, date_col="payment_date")
    if df.empty:
        st.warning("No data.")
        return

    total    = df["transaction_count"].sum()
    suc      = df[df["payment_status"] == "Success"]["transaction_count"].sum()
    failed   = df[df["payment_status"] == "Failed"]["transaction_count"].sum()
    suc_rate = suc / total * 100 if total > 0 else 0
    avg_fraud = df["avg_fraud_score"].mean()

    if total > 0 and failed / total * 100 > 10:
        render_alert_banner(f"High failure rate: {failed / total * 100:.1f}% of transactions failed", "danger")
    if avg_fraud > 0.5:
        render_alert_banner(f"Elevated fraud score: {avg_fraud:.3f} — review flagged transactions", "warning")

    render_kpi_row([
        {"icon": "💳", "label": "Transactions", "value": f"{total:,}"},
        {"icon": "💰", "label": "Total Amount", "value": f"${df['total_amount'].sum():,.0f}", "delta_type": "positive"},
        {"icon": "✅", "label": "Success Rate", "value": f"{suc_rate:.1f}%", "delta_type": "positive" if suc_rate >= 90 else "negative"},
        {"icon": "❌", "label": "Failed",       "value": f"{int(failed):,}", "delta_type": "negative" if failed > 0 else "neutral"},
        {"icon": "🚨", "label": "Avg Fraud",    "value": f"{avg_fraud:.3f}", "delta_type": "negative" if avg_fraud > 0.5 else "neutral"},
    ])
    st.markdown("---")

    c1, c2 = st.columns(2)
    with c1:
        stk = df.groupby(["payment_method", "payment_status"])["transaction_count"].sum().reset_index()
        display_chart(grouped_bar(
            stk, x="payment_method", y="transaction_count", color="payment_status",
            barmode="stack", color_map=PAYMENT_STATUS_COLORS,
            title="Transaction Status by Payment Method",
        ))
    with c2:
        fr = df.groupby("payment_method")["avg_fraud_score"].mean().reset_index().sort_values("avg_fraud_score", ascending=True)
        fig = bar_chart(fr, x="avg_fraud_score", y="payment_method",
                        title="Avg Fraud Score by Method", orientation="h")
        fig.update_traces(marker_color=CHART_COLORS[4])
        display_chart(fig)

    c3, c4 = st.columns(2)
    with c3:
        vol = df.groupby("payment_method")["transaction_count"].sum().reset_index()
        display_chart(pie_chart(vol, names="payment_method", values="transaction_count",
                                title="Transaction Volume by Method"))
    with c4:
        sr = df.groupby("payment_method").apply(
            lambda x: x[x["payment_status"] == "Success"]["transaction_count"].sum() / x["transaction_count"].sum() * 100
            if x["transaction_count"].sum() > 0 else 0
        ).reset_index()
        sr.columns = ["payment_method", "success_rate"]
        sr = sr.sort_values("success_rate", ascending=True)
        fig = bar_chart(sr, x="success_rate", y="payment_method",
                        title="Success Rate % by Method", orientation="h")
        fig.update_traces(marker=dict(color=sr["success_rate"], colorscale="RdYlGn",
                                      cmin=0, cmax=100, showscale=False))
        display_chart(fig)

    c5, c6 = st.columns(2)
    with c5:
        d = df[df["payment_status"] == "Failed"].copy()
        d["payment_date"] = pd.to_datetime(d["payment_date"], errors="coerce")
        tr = d.groupby(d["payment_date"].dt.to_period("M").astype(str))["transaction_count"].sum().reset_index()
        tr.columns = ["month", "failed"]
        fig = line_chart(tr, x="month", y="failed", title="Failed Transaction Trend")
        fig.update_traces(line_color=CHART_COLORS[5])
        display_chart(fig)
    with c6:
        ov = df.groupby("payment_status")["transaction_count"].sum().reset_index()
        display_chart(pie_chart(ov, names="payment_status", values="transaction_count",
                                title="Overall Transaction Status", color_map=PAYMENT_STATUS_COLORS))

    c7, c8 = st.columns(2)
    with c7:
        av = df.groupby("payment_method")["avg_transaction_value"].mean().reset_index().sort_values("avg_transaction_value", ascending=True)
        fig = bar_chart(av, x="avg_transaction_value", y="payment_method",
                        title="Avg Transaction Value by Method", orientation="h")
        fig.update_traces(marker_color=CHART_COLORS[1])
        display_chart(fig)
    with c8:
        cp = df.groupby("payment_method")["transaction_count"].sum().reset_index()
        display_chart(pie_chart(cp, names="payment_method", values="transaction_count",
                                title="Transaction Count by Method", hole=0.0))
