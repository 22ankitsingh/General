"""dashboards/product_performance.py"""
import streamlit as st
from components.kpi_cards import render_kpi_row
from components.filters import product_filters, apply_filters
from components.chart_factory import display_chart, bar_chart, scatter_chart, treemap_chart, kpi_table
from config import CHART_COLORS


def render(df_raw):
    st.markdown('<div class="page-title">📦 Product Performance</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">Revenue, profitability, ratings and brand performance</div>', unsafe_allow_html=True)

    filters = product_filters(df_raw)
    df = apply_filters(df_raw, filters)
    if df.empty:
        st.warning("No data.")
        return

    tr = df["revenue"].sum()
    tp = df["profit_estimate"].sum()

    render_kpi_row([
        {"icon": "💰", "label": "Revenue",    "value": f"${tr:,.0f}", "delta_type": "positive"},
        {"icon": "📈", "label": "Profit",     "value": f"${tp:,.0f}", "delta_type": "positive"},
        {"icon": "📊", "label": "Margin",     "value": f"{tp / tr * 100:.1f}%" if tr > 0 else "N/A",
         "delta_type": "positive" if tr > 0 and tp / tr > 0.2 else "negative"},
        {"icon": "⭐", "label": "Avg Rating", "value": f"{df['avg_review_rating'].mean():.2f}/5"},
        {"icon": "📦", "label": "Units Sold", "value": f"{int(df['units_sold'].sum()):,}"},
    ])
    st.markdown("---")

    c1, c2 = st.columns(2)
    with c1:
        rc = df.groupby("category")["revenue"].sum().reset_index().sort_values("revenue", ascending=True)
        display_chart(bar_chart(rc, x="revenue", y="category", title="Revenue by Category", orientation="h"))
    with c2:
        mg = df.groupby("category").apply(
            lambda x: x["profit_estimate"].sum() / x["revenue"].sum() * 100 if x["revenue"].sum() > 0 else 0
        ).reset_index()
        mg.columns = ["category", "margin"]
        mg = mg.sort_values("margin", ascending=True)
        fig = bar_chart(mg, x="margin", y="category", title="Profit Margin % by Category", orientation="h")
        fig.update_traces(marker_color=CHART_COLORS[1])
        display_chart(fig)

    c3, c4 = st.columns(2)
    with c3:
        uc = df.groupby("category")["units_sold"].sum().reset_index().sort_values("units_sold", ascending=True)
        fig = bar_chart(uc, x="units_sold", y="category", title="Units Sold by Category", orientation="h")
        fig.update_traces(marker_color=CHART_COLORS[2])
        display_chart(fig)
    with c4:
        rc2 = df.groupby("category")["avg_review_rating"].mean().reset_index().sort_values("avg_review_rating", ascending=True)
        fig = bar_chart(rc2, x="avg_review_rating", y="category", title="Avg Rating by Category", orientation="h")
        fig.update_traces(marker=dict(color=rc2["avg_review_rating"], colorscale="RdYlGn",
                                      cmin=1, cmax=5, showscale=False))
        display_chart(fig)

    c5, c6 = st.columns(2)
    with c5:
        t10 = df.nlargest(10, "revenue")[["product_name", "category", "revenue"]].sort_values("revenue")
        display_chart(bar_chart(t10, x="revenue", y="product_name", title="Top 10 Products by Revenue",
                                orientation="h", color="category"))
    with c6:
        s = df.sample(min(300, len(df)), random_state=42)
        display_chart(scatter_chart(s, x="product_price", y="avg_review_rating",
                                    title="Price vs Rating", color="category",
                                    hover_data=["product_name"]))

    c7, c8 = st.columns(2)
    with c7:
        display_chart(scatter_chart(df, x="revenue", y="profit_estimate",
                                    title="Revenue vs Profit by Category", color="category"))
    with c8:
        br = df.groupby("brand")["revenue"].sum().nlargest(15).reset_index().sort_values("revenue", ascending=True)
        fig = bar_chart(br, x="revenue", y="brand", title="Top 15 Brands by Revenue", orientation="h")
        fig.update_traces(marker_color=CHART_COLORS[4])
        display_chart(fig)

    st.markdown('<div class="section-header">Revenue Treemap — Category → Brand</div>', unsafe_allow_html=True)
    display_chart(treemap_chart(df, path=["category", "brand"], values="revenue",
                                color="profit_estimate", height=440))
