# Ecommerce Analytics Copilot

An enterprise-grade, multi-page Streamlit analytics dashboard designed for an e-commerce retail lakehouse. It features a modern, responsive UI with premium aesthetics, a robust theme system, and fully interactive data visualizations.

## Features

- **Multi-Page Architecture**: Navigate seamlessly through dedicated dashboards for Sales, Customers, Inventory, Payments, Products, and Reviews.
- **Enterprise Design System**: Features a custom CSS design system offering both a stunning "Dark Pro" theme and a clean Light theme with perfect contrast.
- **Interactive Data Visualizations**: Built with `plotly`, every chart supports full interactivity including zooming, panning, and high-resolution PNG downloads.
- **Premium UI Components**: Beautifully styled KPI cards with hover animations, delta indicators (▲/▼), and glassmorphism alert banners.
- **AI Analytics Copilot**: An integrated GPT-4o assistant designed to analyze dashboard data and provide actionable insights.
- **Light/Dark Mode Toggle**: Fluid theme switching that automatically updates the app shell, sidebar, widgets, and all Plotly charts (`plotly` vs `plotly_dark` templates).

## Project Structure

- `app.py`: The main entry point and home dashboard.
- `pages/`: Individual Streamlit pages mapped to specific analytics domains.
- `dashboards/`: Core rendering logic for each analytics view (e.g., `sales_summary.py`).
- `components/`: Reusable UI building blocks (`chart_factory.py`, `kpi_cards.py`, `theme.py`, `filters.py`).
- `services/`: Backend logic, such as data loading and external API connections.
- `utils/`: Helpers including the core `session_manager.py`.
- `assets/style.css`: The central design system containing CSS variables and custom styling.

## Running the Dashboard

Ensure you have the necessary dependencies installed (`streamlit`, `pandas`, `plotly`), then run:

```bash
streamlit run app.py
```

## Recent Upgrades
The UI was recently completely refactored to production-grade quality without altering the underlying business logic. Key improvements include a unified chart factory, standardized responsive layouts, improved tooltip formatting, and comprehensive theme awareness across all components.
