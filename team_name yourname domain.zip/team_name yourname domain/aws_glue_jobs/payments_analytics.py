"""
Glue ETL Job : payment_summary
Source DB    : ecommerce_silver_db
Sources      : payments, orders
Output       : s3://ecommerce-lakehouse-project-2026/gold/payment_summary/
Partition    : payment_method

NOTE: No spark.sql catalog registration here.
      After this job runs, trigger the payment_summary_gold_crawler
      to register the table in ecommerce_gold_db.
"""

import sys
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args  = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc    = SparkContext()
glue  = GlueContext(sc)
spark = glue.spark_session
job   = Job(glue)
job.init(args["JOB_NAME"], args)

SOURCE_DB = "ecommerce_silver_db"
GOLD_S3   = "s3://ecommerce-lakehouse-project-2026/gold/payment_summary/"

# ── 1. Read silver tables ─────────────────────────────────────────────────────
payments = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="payments"
).toDF()

orders = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="orders"
).toDF()

# ── 2. Join payments → orders for order_date ──────────────────────────────────
pay = payments.join(
    orders.select("order_id", "order_date"),
    on="order_id",
    how="left"
)

# ── 3. Aggregate by payment_date + payment_method + payment_status ────────────
gold = pay.groupBy(
    "payment_date",
    "payment_method",
    "payment_status",
).agg(
    F.count("payment_id")  .alias("transaction_count"),
    F.sum("amount")        .alias("total_amount"),
    F.avg("amount")        .alias("avg_transaction_value"),
    F.avg("fraud_score")   .alias("avg_fraud_score"),
)

# ── 4. Round numeric columns ──────────────────────────────────────────────────
gold = gold \
    .withColumn("total_amount",          F.round(F.col("total_amount"),          2)) \
    .withColumn("avg_transaction_value", F.round(F.col("avg_transaction_value"), 2)) \
    .withColumn("avg_fraud_score",       F.round(F.col("avg_fraud_score"),       4)) \
    .withColumn("etl_timestamp",         F.current_timestamp())

# ── 5. Write parquet to S3 ────────────────────────────────────────────────────
gold.write \
    .mode("overwrite") \
    .option("compression", "snappy") \
    .partitionBy("payment_method") \
    .parquet(GOLD_S3)

print(f"✅  payment_summary written to {GOLD_S3}")
print("👉  Now run the payment_summary_gold_crawler to register in ecommerce_gold_db")
job.commit()