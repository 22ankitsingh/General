"""
Glue ETL Job : customer_analytics
Source DB    : ecommerce_silver_db
Sources      : customers, orders, payments
Output       : s3://ecommerce-lakehouse-project-2026/gold/customer_analytics/
Partition    : country, customer_segment

NOTE: No spark.sql catalog registration here.
      After this job runs, trigger the customer_analytics_gold_crawler
      to register the table in ecommerce_gold_db.
"""

import sys
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql.window import Window

args  = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc    = SparkContext()
glue  = GlueContext(sc)
spark = glue.spark_session
job   = Job(glue)
job.init(args["JOB_NAME"], args)

SOURCE_DB = "ecommerce_silver_db"
GOLD_S3   = "s3://ecommerce-lakehouse-project-2026/gold/customer_analytics/"

# ── 1. Read silver tables ─────────────────────────────────────────────────────
customers = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="customers"
).toDF()

orders = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="orders"
).toDF()

payments = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="payments"
).toDF()

# ── 2. Aggregate orders per customer BEFORE joining ───────────────────────────
# Aggregating first prevents any row fan-out from the join
order_agg = orders.groupBy("customer_id").agg(
    F.count("order_id")       .alias("total_orders"),
    F.sum("total_amount")     .alias("lifetime_value"),
    F.avg("total_amount")     .alias("avg_order_value"),
    F.max("order_date")       .alias("last_order_date"),
)

# ── 3. Preferred payment method per customer ──────────────────────────────────
pay_with_customer = payments.join(
    orders.select("order_id", "customer_id"),
    on="order_id",
    how="inner"
)

pay_counts = pay_with_customer.groupBy("customer_id", "payment_method").agg(
    F.count("*").alias("pay_count")
)

win = Window.partitionBy("customer_id").orderBy(F.desc("pay_count"))

preferred_payment = pay_counts \
    .withColumn("rn", F.row_number().over(win)) \
    .filter(F.col("rn") == 1) \
    .select("customer_id", F.col("payment_method").alias("preferred_payment_method"))

# ── 4. Build full name ────────────────────────────────────────────────────────
customers = customers.withColumn(
    "customer_name",
    F.concat_ws(" ", F.col("first_name"), F.col("last_name"))
)

# ── 5. Join everything ────────────────────────────────────────────────────────
gold = customers.select(
    "customer_id",
    "customer_name",
    "customer_segment",
    "customer_status",
    "city",
    "state",
    "country",
    "loyalty_points",
    "annual_income",
) \
.join(order_agg,         on="customer_id", how="left") \
.join(preferred_payment, on="customer_id", how="left") \
.withColumn("lifetime_value",  F.round(F.col("lifetime_value"),  2)) \
.withColumn("avg_order_value", F.round(F.col("avg_order_value"), 2)) \
.withColumn("etl_timestamp",   F.current_timestamp())

# ── 6. Write parquet to S3 ────────────────────────────────────────────────────
gold.write \
    .mode("overwrite") \
    .option("compression", "snappy") \
    .partitionBy("country", "customer_segment") \
    .parquet(GOLD_S3)

print(f"✅  customer_analytics written to {GOLD_S3}")
print("👉  Now run the customer_analytics_gold_crawler to register in ecommerce_gold_db")
job.commit()