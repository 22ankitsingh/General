
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import (
    col,
    trim,
    lower,
    upper,
    current_timestamp,
    to_date,
    coalesce
)

# =====================================
# Glue Setup
# =====================================

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

DATABASE = "ecommerce_bronze_db"
SILVER_PATH = "s3://ecommerce-lakehouse-project-2026/silver/"

TABLES = [
    "customers",
    "products",
    "orders",
    "inventory",
    "reviews",
    "order_items",
    "payments"
]

for table in TABLES:

    print(f"Processing table: {table}")

    df = glueContext.create_dynamic_frame.from_catalog(
        database=DATABASE,
        table_name=table
    ).toDF()

    # =====================================
    # Remove completely empty rows
    # =====================================

    df = df.na.drop(how="all")

    # =====================================
    # Convert all date columns from
    # string/varchar to DateType
    # =====================================

    for column_name, column_type in df.dtypes:

        if column_type == "string" and "date" in column_name.lower():

            df = df.withColumn(
                column_name,
                coalesce(
                    to_date(col(column_name), "yyyy-MM-dd"),
                    to_date(col(column_name), "yyyy/MM/dd"),
                    to_date(col(column_name), "dd-MM-yyyy"),
                    to_date(col(column_name), "MM/dd/yyyy")
                )
            )

    # ====================================================
    # CUSTOMERS
    # ====================================================

    if table == "customers":

        df = df.dropDuplicates(["customer_id"])
        df = df.filter(col("customer_id").isNotNull())

        df = df.withColumn(
            "email",
            lower(trim(col("email")))
        )

        df = df.withColumn(
            "customer_status",
            trim(col("customer_status"))
        )

        df = df.filter(
            col("customer_status").isin(
                "Active",
                "Inactive"
            )
        )

        df = df.filter(col("loyalty_points") >= 0)
        df = df.filter(col("annual_income") > 0)

    # ====================================================
    # PRODUCTS
    # ====================================================

    elif table == "products":

        df = df.dropDuplicates(["product_id"])
        df = df.filter(col("product_id").isNotNull())

        df = df.filter(col("price") > 0)
        df = df.filter(col("cost") > 0)
        df = df.filter(col("price") > col("cost"))

        df = df.filter(
            (col("rating") >= 1.0) &
            (col("rating") <= 5.0)
        )

        df = df.withColumn(
            "is_active",
            trim(col("is_active"))
        )

    # ====================================================
    # ORDERS
    # ====================================================

    elif table == "orders":

        df = df.dropDuplicates(["order_id"])
        df = df.filter(col("order_id").isNotNull())
        df = df.filter(col("customer_id").isNotNull())

        df = df.filter(col("total_amount") > 0)
        df = df.filter(col("shipping_cost") >= 0)
        df = df.filter(col("discount_amount") >= 0)

    # ====================================================
    # ORDER ITEMS
    # ====================================================

    elif table == "order_items":

        df = df.dropDuplicates(["order_item_id"])

        df = df.filter(col("quantity") > 0)
        df = df.filter(col("unit_price") > 0)
        df = df.filter(col("item_total") > 0)
        df = df.filter(col("item_discount") >= 0)

    # ====================================================
    # PAYMENTS
    # ====================================================

    elif table == "payments":

        df = df.dropDuplicates(["payment_id"])

        df = df.filter(col("amount") > 0)

        df = df.filter(
            (col("fraud_score") >= 0) &
            (col("fraud_score") <= 100)
        )

        df = df.filter(
            col("payment_status").isin(
                "Success",
                "Refunded",
                "Failed",
                "Pending"
            )
        )

        df = df.filter(
            col("currency").isin(
                "INR",
                "USD",
                "GBP",
                "CAD",
                "AUD"
            )
        )

    # ====================================================
    # INVENTORY
    # ====================================================

    elif table == "inventory":

        df = df.dropDuplicates(["inventory_id"])

        df = df.filter(col("stock_on_hand") >= 0)
        df = df.filter(col("stock_reserved") >= 0)

        df = df.filter(
            col("stock_reserved") <= col("stock_on_hand")
        )

        df = df.filter(col("reorder_point") >= 0)
        df = df.filter(col("lead_time_days") > 0)

    # ====================================================
    # REVIEWS
    # ====================================================

    elif table == "reviews":

        df = df.dropDuplicates(["review_id"])

        df = df.filter(
            (col("rating") >= 1) &
            (col("rating") <= 5)
        )

        df = df.filter(
            col("verified_purchase") == "Yes"
        )

        df = df.filter(
            col("sentiment").isin(
                "Positive",
                "Neutral",
                "Negative"
            )
        )

    # ====================================================
    # AUDIT COLUMN
    # ====================================================

    df = df.withColumn(
        "silver_processed_ts",
        current_timestamp()
    )

    # ====================================================
    # WRITE SILVER DATA
    # ====================================================

    (
        df.write
          .mode("overwrite")
          .parquet(f"{SILVER_PATH}{table}/")
    )

    print(f"Completed table: {table}")

print("Bronze -> Silver ETL completed successfully")