"""
Glue ETL Job : inventory_health
Source DB    : ecommerce_silver_db
Sources      : inventory, products
Output       : s3://ecommerce-lakehouse-project-2026/gold/inventory_health/
Partition    : warehouse_country

NOTE: No spark.sql catalog registration here.
      After this job runs, trigger the inventory_health_gold_crawler
      to register the table in ecommerce_gold_db.
"""

import sys
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args  = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc    = SparkContext()
glue  = GlueContext(sc)
spark = glue.spark_session
job   = Job(glue)
job.init(args["JOB_NAME"], args)

SOURCE_DB = "ecommerce_silver_db"
GOLD_S3   = "s3://ecommerce-lakehouse-project-2026/gold/inventory_health/"

# ── 1. Read silver tables ─────────────────────────────────────────────────────
inventory = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="inventory"
).toDF()

products = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="products"
).toDF()

# ── 2. Join inventory with product name + price ───────────────────────────────
gold = inventory.join(
    products.select("product_id", "product_name", "price"),
    on="product_id",
    how="left"
)

# ── 3. Derived columns ────────────────────────────────────────────────────────

# available_stock = stock_on_hand - stock_reserved
gold = gold.withColumn(
    "available_stock",
    F.col("stock_on_hand") - F.col("stock_reserved")
)

# inventory_value = stock_on_hand * price
gold = gold.withColumn(
    "inventory_value",
    F.round(F.col("stock_on_hand") * F.col("price"), 2)
)

# low_stock_flag = available_stock <= reorder_point
gold = gold.withColumn(
    "low_stock_flag",
    F.col("available_stock") <= F.col("reorder_point")
)

# ── 4. Select final columns ───────────────────────────────────────────────────
gold = gold.select(
    "inventory_id",
    "product_id",
    "product_name",
    "warehouse_id",
    "warehouse_city",
    "warehouse_country",
    "stock_on_hand",
    "stock_reserved",
    "available_stock",
    "reorder_point",
    "inventory_value",
    "inventory_status",
    "low_stock_flag",
    F.current_timestamp().alias("etl_timestamp"),
)

# ── 5. Write parquet to S3 ────────────────────────────────────────────────────
gold.write \
    .mode("overwrite") \
    .option("compression", "snappy") \
    .partitionBy("warehouse_country") \
    .parquet(GOLD_S3)

print(f"✅  inventory_health written to {GOLD_S3}")
print("👉  Now run the inventory_health_gold_crawler to register in ecommerce_gold_db")
job.commit()