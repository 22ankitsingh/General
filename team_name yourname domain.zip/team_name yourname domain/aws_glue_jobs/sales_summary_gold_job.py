import sys
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F

# ====================================================
# INITIALIZE GLUE JOB
# ====================================================

args = getResolvedOptions(sys.argv, ["JOB_NAME"])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# ====================================================
# CONFIGURATION
# ====================================================

SILVER_DB = "ecommerce_silver_db"

GOLD_PATH = (
    "s3://ecommerce-lakehouse-project-2026/gold/sales_summary/"
)

# ====================================================
# READ SILVER TABLES
# ====================================================

orders = glueContext.create_dynamic_frame.from_catalog(
    database=SILVER_DB,
    table_name="orders"
).toDF()

order_items = glueContext.create_dynamic_frame.from_catalog(
    database=SILVER_DB,
    table_name="order_items"
).toDF()

# ====================================================
# DATE ATTRIBUTES
# ====================================================

orders = (
    orders
    .withColumn("order_year", F.year("order_date"))
    .withColumn("order_month", F.month("order_date"))
    .withColumn(
        "fulfillment_days",
        F.datediff(
            F.col("delivery_date"),
            F.col("order_date")
        )
    )
)

# ====================================================
# JOIN ORDERS AND ORDER ITEMS
# ====================================================

sales_df = orders.join(
    order_items,
    "order_id",
    "left"
)

# ====================================================
# SALES AGGREGATION
# ====================================================

gold_df = (
    sales_df
    .groupBy(
        "order_date",
        "order_year",
        "order_month"
    )
    .agg(
        F.countDistinct("order_id")
            .alias("total_orders"),

        F.countDistinct("customer_id")
            .alias("unique_customers"),

        F.round(
            F.sum("total_amount"), 2
        ).alias("gross_revenue"),

        F.round(
            F.sum("discount_amount"), 2
        ).alias("total_discounts"),

        F.round(
            F.sum("tax_amount"), 2
        ).alias("total_tax"),

        F.round(
            F.sum("shipping_cost"), 2
        ).alias("shipping_cost"),

        F.round(
            F.sum("total_amount")
            - F.sum("discount_amount"),
            2
        ).alias("net_revenue"),

        F.sum("quantity")
            .alias("total_units_sold"),

        F.round(
            F.avg("total_amount"), 2
        ).alias("avg_order_value"),

        F.round(
            F.avg("fulfillment_days"), 2
        ).alias("avg_fulfillment_days")
    )
    .withColumn(
        "etl_timestamp",
        F.current_timestamp()
    )
)

# ====================================================
# WRITE GOLD LAYER
# ====================================================

(
    gold_df.write
    .mode("overwrite")
    .partitionBy(
        "order_year",
        "order_month"
    )
    .parquet(GOLD_PATH)
)

# ====================================================
# COMMIT JOB
# ====================================================

job.commit()