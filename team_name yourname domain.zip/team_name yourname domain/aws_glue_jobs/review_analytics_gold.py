"""
Glue ETL Job : review_analytics_gold
Source DB    : ecommerce_silver_db
Sources      : reviews, customers, orders, products
Output       : s3://ecommerce-lakehouse-project-2026/gold/review_analytics/
Partition    : category

NOTE: No spark.sql catalog registration.
      After this job runs, manually create and run a crawler
      pointing to s3://ecommerce-lakehouse-project-2026/gold/review_analytics/
      to register in ecommerce_gold_db.
"""

import sys
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql.window import Window

args  = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc    = SparkContext()
glue  = GlueContext(sc)
spark = glue.spark_session
job   = Job(glue)
job.init(args["JOB_NAME"], args)

SOURCE_DB = "ecommerce_silver_db"
GOLD_S3   = "s3://ecommerce-lakehouse-project-2026/gold/review_analytics/"

# ── 1. Read silver tables ─────────────────────────────────────────────────────
reviews = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="reviews"
).toDF()

customers = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="customers"
).toDF()

orders = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="orders"
).toDF()

products = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="products"
).toDF()

# ── 2. Cast columns ───────────────────────────────────────────────────────────
reviews = reviews \
    .withColumn("rating",      F.col("rating").cast("double")) \
    .withColumn("review_date", F.to_date(F.col("review_date"))) \
    .withColumn("review_year", F.year("review_date")) \
    .withColumn("review_month", F.month("review_date")) \
    .withColumn(
        "verified_purchase",
        F.when(
            F.upper(F.col("verified_purchase")).isin("TRUE", "YES", "Y", "1"),
            True
        ).otherwise(False)
    )

orders = orders \
    .withColumn("order_date", F.to_date(F.col("order_date")))

# ── 3. Prepare customers — build full name, keep needed cols ──────────────────
customers = customers \
    .withColumn("customer_name",
        F.concat_ws(" ", F.col("first_name"), F.col("last_name"))) \
    .select(
        "customer_id", "customer_name",
        "customer_segment", "customer_status",
        "city", "country"
    )

# ── 4. Prepare products — rename rating to avoid collision ────────────────────
products = products \
    .withColumnRenamed("rating", "product_catalogue_rating") \
    .select(
        "product_id", "product_name", "brand",
        "category", "subcategory",
        "product_catalogue_rating"
    )

orders = orders.select("order_id", "order_date", "order_status")

# ── 5. Join reviews → customers, products, orders ─────────────────────────────
enriched = reviews \
    .join(customers, on="customer_id", how="left") \
    .join(products,  on="product_id",  how="left") \
    .join(orders,    on="order_id",    how="left")

# ── 6. Normalise sentiment to title case, add NPS category ───────────────────
enriched = enriched \
    .withColumn("sentiment", F.initcap(F.col("sentiment"))) \
    .withColumn("nps_category",
        F.when(F.col("rating") == 5, "Promoter")
         .when(F.col("rating") == 4, "Passive")
         .otherwise("Detractor")
    )

# ── 7. Product-level aggregations ─────────────────────────────────────────────
product_stats = reviews.groupBy("product_id").agg(
    F.count("review_id")                                                    .alias("total_reviews"),
    F.round(F.avg("rating"), 2)                                             .alias("avg_rating"),
    F.sum(F.when(F.col("rating") == 5, 1).otherwise(0))                    .alias("star_5_count"),
    F.sum(F.when(F.col("rating") == 4, 1).otherwise(0))                    .alias("star_4_count"),
    F.sum(F.when(F.col("rating") == 3, 1).otherwise(0))                    .alias("star_3_count"),
    F.sum(F.when(F.col("rating") == 2, 1).otherwise(0))                    .alias("star_2_count"),
    F.sum(F.when(F.col("rating") == 1, 1).otherwise(0))                    .alias("star_1_count"),
    F.sum(F.when(F.col("verified_purchase") == True, 1).otherwise(0))      .alias("verified_count"),
    F.sum(F.when(F.upper(F.col("sentiment")) == "POSITIVE", 1).otherwise(0)).alias("positive_count"),
    F.sum(F.when(F.upper(F.col("sentiment")) == "NEGATIVE", 1).otherwise(0)).alias("negative_count"),
    F.sum(F.when(F.upper(F.col("sentiment")) == "NEUTRAL",  1).otherwise(0)).alias("neutral_count"),
    F.min("review_date")                                                    .alias("first_review_date"),
    F.max("review_date")                                                    .alias("last_review_date"),
)

# ── 7b. Derived rates — no nullif, use WHEN guard instead ────────────────────
product_stats = product_stats \
    .withColumn("positive_rate_pct",
        F.when(
            F.col("total_reviews") > 0,
            F.round((F.col("positive_count") / F.col("total_reviews")) * 100, 2)
        ).otherwise(F.lit(0.0))
    ) \
    .withColumn("negative_rate_pct",
        F.when(
            F.col("total_reviews") > 0,
            F.round((F.col("negative_count") / F.col("total_reviews")) * 100, 2)
        ).otherwise(F.lit(0.0))
    ) \
    .withColumn("verified_rate_pct",
        F.when(
            F.col("total_reviews") > 0,
            F.round((F.col("verified_count") / F.col("total_reviews")) * 100, 2)
        ).otherwise(F.lit(0.0))
    )

# ── 8. Monthly rating trend per product ───────────────────────────────────────
monthly = reviews.groupBy("product_id", "review_year", "review_month").agg(
    F.round(F.avg("rating"), 2).alias("monthly_avg_rating"),
    F.count("*")               .alias("monthly_review_count"),
)

win_lag = Window.partitionBy("product_id").orderBy("review_year", "review_month")

monthly = monthly \
    .withColumn("prev_avg_rating", F.lag("monthly_avg_rating", 1).over(win_lag)) \
    .withColumn("rating_trend",
        F.when(F.col("monthly_avg_rating") > F.col("prev_avg_rating"), "Improving")
         .when(F.col("monthly_avg_rating") < F.col("prev_avg_rating"), "Declining")
         .otherwise("Stable")
    )

# Keep only latest month per product
latest_trend = monthly.withColumn(
    "rn", F.row_number().over(
        Window.partitionBy("product_id")
              .orderBy(F.desc("review_year"), F.desc("review_month"))
    )
).filter(F.col("rn") == 1) \
 .select(
     "product_id",
     F.col("monthly_avg_rating").alias("latest_month_avg_rating"),
     F.col("monthly_review_count").alias("latest_month_review_count"),
     "rating_trend"
 )

# ── 9. Category-level stats ───────────────────────────────────────────────────
cat_stats = enriched.groupBy("category").agg(
    F.round(F.avg("rating"), 2).alias("category_avg_rating"),
    F.count("review_id")       .alias("category_total_reviews"),
)

# ── 10. Prolific reviewer flag (top 10% by review volume) ────────────────────
reviewer_vol = reviews.groupBy("customer_id").agg(
    F.count("*").alias("customer_review_count")
)
reviewer_vol = reviewer_vol.withColumn(
    "reviewer_pct",
    F.percent_rank().over(Window.orderBy("customer_review_count")) * 100
).withColumn(
    "is_prolific_reviewer",
    F.col("reviewer_pct") >= 90
)

# ── 11. Assemble final gold table ─────────────────────────────────────────────
gold = enriched \
    .join(product_stats.select(
        "product_id", "total_reviews", "avg_rating",
        "positive_rate_pct", "negative_rate_pct", "verified_rate_pct",
        "star_5_count", "star_4_count", "star_3_count",
        "star_2_count", "star_1_count",
        "first_review_date", "last_review_date"
    ), on="product_id", how="left") \
    .join(latest_trend,  on="product_id", how="left") \
    .join(cat_stats,     on="category",   how="left") \
    .join(reviewer_vol.select(
        "customer_id", "customer_review_count", "is_prolific_reviewer"
    ), on="customer_id", how="left") \
    .withColumn("etl_timestamp", F.current_timestamp()) \
    .drop("silver_processed_ts")

# ── 12. Write Gold partitioned by category ────────────────────────────────────
gold.write \
    .mode("overwrite") \
    .option("compression", "snappy") \
    .partitionBy("category") \
    .parquet(GOLD_S3)

print(f"✅  review_analytics written → {GOLD_S3}")
print("👉  Now create and run a Glue Crawler on that S3 path to register in ecommerce_gold_db")
job.commit()