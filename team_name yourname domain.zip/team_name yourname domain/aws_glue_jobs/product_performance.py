"""
Glue ETL Job : product_performance
Source DB    : ecommerce_silver_db
Sources      : products, order_items, reviews
Output       : s3://ecommerce-lakehouse-project-2026/gold/product_performance/
Partition    : category

NOTE: No spark.sql catalog registration here.
      After this job runs, trigger the product_performance_gold_crawler
      to register the table in ecommerce_gold_db.
"""

import sys
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args  = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc    = SparkContext()
glue  = GlueContext(sc)
spark = glue.spark_session
job   = Job(glue)
job.init(args["JOB_NAME"], args)

SOURCE_DB = "ecommerce_silver_db"
GOLD_S3   = "s3://ecommerce-lakehouse-project-2026/gold/product_performance/"

# ── 1. Read silver tables ─────────────────────────────────────────────────────
products = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="products"
).toDF()

order_items = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="order_items"
).toDF()

reviews = glue.create_dynamic_frame.from_catalog(
    database=SOURCE_DB, table_name="reviews"
).toDF()

# ── 2. Sales aggregation per product ─────────────────────────────────────────
# Use item_total from order_items — never SUM(total_amount) from orders
sales_agg = order_items.groupBy("product_id").agg(
    F.sum("quantity")    .alias("units_sold"),
    F.sum("item_total")  .alias("revenue"),
)

# ── 3. Review aggregation per product ─────────────────────────────────────────
review_agg = reviews.groupBy("product_id").agg(
    F.avg("rating")      .alias("avg_review_rating"),
    F.count("review_id") .alias("review_count"),
)

# ── 4. Join products + sales + reviews ───────────────────────────────────────
gold = products.select(
    "product_id",
    "product_name",
    "brand",
    "category",
    "subcategory",
    F.col("price").alias("product_price"),
    F.col("cost").alias("product_cost"),
) \
.join(sales_agg,  on="product_id", how="left") \
.join(review_agg, on="product_id", how="left")

# ── 5. Derived columns ────────────────────────────────────────────────────────
# profit_estimate = revenue - (units_sold * cost)
gold = gold \
    .withColumn(
        "profit_estimate",
        F.round(F.col("revenue") - (F.col("units_sold") * F.col("product_cost")), 2)
    ) \
    .withColumn("revenue",           F.round(F.col("revenue"),           2)) \
    .withColumn("avg_review_rating", F.round(F.col("avg_review_rating"), 2)) \
    .withColumn("etl_timestamp",     F.current_timestamp())

# ── 6. Write parquet to S3 ────────────────────────────────────────────────────
gold.write \
    .mode("overwrite") \
    .option("compression", "snappy") \
    .partitionBy("category") \
    .parquet(GOLD_S3)

print(f"✅  product_performance written to {GOLD_S3}")
print("👉  Now run the product_performance_gold_crawler to register in ecommerce_gold_db")
job.commit()