"""
Glue ETL Job: sales_summary_gold
=================================
Sources  : ecommerce_bronze_db.orders, ecommerce_bronze_db.order_items
Target   : s3://ecommerce-lakehouse-project-2026/gold/sales_summary_gold/
Catalog  : ecommerce_gold_db.sales_summary_gold

Actual column names
-------------------
orders      : order_id, customer_id, order_date, order_status, shipping_method,
              shipping_cost, discount_amount, tax_amount, total_amount, delivery_date
order_items : order_item_id, order_id, product_id, quantity, unit_price,
              item_discount, item_total
"""

import sys
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql.window import Window

args  = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc    = SparkContext()
glue  = GlueContext(sc)
spark = glue.spark_session
job   = Job(glue)
job.init(args["JOB_NAME"], args)

BUCKET       = "ecommerce-lakehouse-project-2026"
SILVER_DB    = "ecommerce_bronze_db"
GOLD_DB      = "ecommerce_gold_db"
GOLD_S3      = f"s3://{BUCKET}/gold/sales_summary_gold/"
TARGET_TABLE = "sales_summary_gold"

# ── Read Silver ───────────────────────────────────────────────────────────────
orders = glue.create_dynamic_frame.from_catalog(
    database=SILVER_DB, table_name="orders"
).toDF()

order_items = glue.create_dynamic_frame.from_catalog(
    database=SILVER_DB, table_name="order_items"
).toDF()

# ── Cast columns ──────────────────────────────────────────────────────────────
orders = (
    orders
    .withColumn("order_date",       F.to_date(F.col("order_date")))
    .withColumn("delivery_date",    F.to_date(F.col("delivery_date")))
    .withColumn("shipping_cost",    F.col("shipping_cost").cast("double"))
    .withColumn("discount_amount",  F.col("discount_amount").cast("double"))
    .withColumn("tax_amount",       F.col("tax_amount").cast("double"))
    .withColumn("total_amount",     F.col("total_amount").cast("double"))
)

order_items = (
    order_items
    .withColumn("quantity",       F.col("quantity").cast("int"))
    .withColumn("unit_price",     F.col("unit_price").cast("double"))
    .withColumn("item_discount",  F.col("item_discount").cast("double"))
    .withColumn("item_total",     F.col("item_total").cast("double"))
)

# ── Date dimension columns ────────────────────────────────────────────────────
orders = (
    orders
    .withColumn("order_year",    F.year("order_date"))
    .withColumn("order_month",   F.month("order_date"))
    .withColumn("order_day",     F.dayofmonth("order_date"))
    .withColumn("order_week",    F.weekofyear("order_date"))
    .withColumn("day_of_week",   F.dayofweek("order_date"))
    .withColumn("fulfilment_days",
        F.datediff(F.col("delivery_date"), F.col("order_date")))
)

# ── Join orders → order_items ─────────────────────────────────────────────────
df = orders.join(order_items, on="order_id", how="left")

# ── Daily summary ─────────────────────────────────────────────────────────────
daily = df.groupBy(
    "order_date", "order_year", "order_month", "order_day",
    "order_week", "day_of_week", "order_status", "shipping_method"
).agg(
    F.countDistinct("order_id")           .alias("total_orders"),
    F.countDistinct("customer_id")        .alias("unique_customers"),
    F.sum("total_amount")                 .alias("gross_revenue"),
    F.sum("discount_amount")              .alias("total_discounts"),
    F.sum("tax_amount")                   .alias("total_tax"),
    F.sum("shipping_cost")                .alias("total_shipping_cost"),
    (F.sum("total_amount") - F.sum("discount_amount"))
                                          .alias("net_revenue"),
    F.avg("total_amount")                 .alias("avg_order_value"),
    F.max("total_amount")                 .alias("max_order_value"),
    F.min("total_amount")                 .alias("min_order_value"),
    F.sum("quantity")                     .alias("total_units_sold"),
    F.sum("item_discount")                .alias("total_item_discounts"),
    F.avg("fulfilment_days")              .alias("avg_fulfilment_days"),
)

# ── Monthly summary ────────────────────────────────────────────────────────────
monthly = df.groupBy(
    "order_year", "order_month", "order_status", "shipping_method"
).agg(
    F.countDistinct("order_id")           .alias("total_orders"),
    F.countDistinct("customer_id")        .alias("unique_customers"),
    F.sum("total_amount")                 .alias("gross_revenue"),
    F.sum("discount_amount")              .alias("total_discounts"),
    F.sum("tax_amount")                   .alias("total_tax"),
    F.sum("shipping_cost")                .alias("total_shipping_cost"),
    (F.sum("total_amount") - F.sum("discount_amount"))
                                          .alias("net_revenue"),
    F.avg("total_amount")                 .alias("avg_order_value"),
    F.max("total_amount")                 .alias("max_order_value"),
    F.min("total_amount")                 .alias("min_order_value"),
    F.sum("quantity")                     .alias("total_units_sold"),
    F.sum("item_discount")                .alias("total_item_discounts"),
    F.avg("fulfilment_days")              .alias("avg_fulfilment_days"),
)

# ── Rolling 30-day revenue window (daily only) ────────────────────────────────
win_30d = Window.orderBy(F.col("order_date").cast("long")).rowsBetween(-29, 0)
daily = daily.withColumn("rolling_30d_revenue", F.sum("gross_revenue").over(win_30d))

# ── Add grain tag + metadata ──────────────────────────────────────────────────
daily   = daily.withColumn("grain", F.lit("daily")) \
               .withColumn("etl_timestamp", F.current_timestamp())

monthly = monthly \
    .withColumn("order_date",           F.lit(None).cast("date")) \
    .withColumn("order_day",            F.lit(None).cast("int")) \
    .withColumn("order_week",           F.lit(None).cast("int")) \
    .withColumn("day_of_week",          F.lit(None).cast("int")) \
    .withColumn("rolling_30d_revenue",  F.lit(None).cast("double")) \
    .withColumn("grain",                F.lit("monthly")) \
    .withColumn("etl_timestamp",        F.current_timestamp())

# ── Union daily + monthly ─────────────────────────────────────────────────────
COLS = [
    "order_date", "order_year", "order_month", "order_day", "order_week",
    "day_of_week", "order_status", "shipping_method",
    "total_orders", "unique_customers",
    "gross_revenue", "total_discounts", "total_tax", "total_shipping_cost",
    "net_revenue", "avg_order_value", "max_order_value", "min_order_value",
    "total_units_sold", "total_item_discounts", "avg_fulfilment_days",
    "rolling_30d_revenue", "grain", "etl_timestamp",
]

gold = daily.select(COLS).unionByName(monthly.select(COLS))

# ── Write Gold ────────────────────────────────────────────────────────────────
gold.write.mode("overwrite") \
    .option("compression", "snappy") \
    .partitionBy("order_year", "order_month") \
    .parquet(GOLD_S3)

# ── Register in Glue Catalog ──────────────────────────────────────────────────
spark.sql(f"CREATE DATABASE IF NOT EXISTS {GOLD_DB}")
spark.sql(f"DROP TABLE IF EXISTS {GOLD_DB}.{TARGET_TABLE}")
spark.sql(f"""
    CREATE TABLE {GOLD_DB}.{TARGET_TABLE}
    USING parquet
    PARTITIONED BY (order_year, order_month)
    LOCATION '{GOLD_S3}'
""")
spark.sql(f"MSCK REPAIR TABLE {GOLD_DB}.{TARGET_TABLE}")

print(f"✅  {TARGET_TABLE}  →  {GOLD_S3}")
job.commit()